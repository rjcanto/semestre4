#ifndef MINESWEEPER_H
#define MINESWEEPER_H
  public static Board board;
  public static boolean exit;
  
  public static void main(String[] args);
}

#endif
