#ifndef BOMBCELL_H
#define BOMBCELL_H
boolean exploded = false;
char BombCell_getView();
void BombCell_touch();
boolean BombCell_isBomb();
}
#endif
