
void start_timer();

/* returns the time elapsed since start_timer() call */
/* in micro seconds. */
long get_microtime();

/* returns the time elapsed since start_timer() call */
/* in nano seconds. */
long long get_nanotime();

