/*
Turma: 	LI31N
Nome: 	Nuno Cancelo
Numero: 31401
*/
#ifndef _SERIE01_EX02
#define _SERIE01_EX02

#include "serie01.h"
#define STR_MAX_SIZE 255
#define MAX_SIZE 510

char * xstrcat(char * str1, const char * str2);

#endif
