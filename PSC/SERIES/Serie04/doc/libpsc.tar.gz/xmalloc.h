#ifndef XMALLOC_H
#define XMALLOC_H

void * xmalloc(unsigned int size);
void xfree(void * ptr);

#endif

