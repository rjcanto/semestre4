/*
 * ISEL - POO
 * 3º trabalho Semestre Verão 2009/2010
 * 33595 - Nuno Sousa
 */
package SameGame.Game.gui;

public interface GameGUIVars_I {
    public final String BLOCKSHAPES_PACKAGE="build/classes/Samegame/game/gui/BlockShapes";
    public final String LAYOUTS_PACKAGE="build/classes/Samegame/game/gui/Layouts";
    public final String FRAMEBG_IMAGEPATH ="src/SameGame/images/FrameBG/";
    public final String INFO2_IMAGEPATH ="src/SameGame/images/Layouts/Layout2/infoBG/";
    public final String INFO1_IMAGEPATH ="src/SameGame/images/Layouts/Layout1/infoBG/";
    public final String ICON_RR_IMAGEPATH ="src/SameGame/images/sub_black_rotate_cw.png";
    public final String ICON_RL_IMAGEPATH ="src/SameGame/images/sub_black_rotate_ccw.png";
}
