/*
 * ISEL - POO
 * 3º trabalho Semestre Verão 2009/2010
 * 33595 - Nuno Sousa
 */
package SameGame.Fonts;

import java.awt.Font;


public class Fonts{
    public static final Font INFOFONT_LARGE = new Font("Times New Roman", Font.BOLD, 32);
    public static final Font INFOFONT_MEDIUM = new Font("Times New Roman", Font.BOLD, 24);
    public static final Font INFOFONT_SMALL = new Font("Times New Roman", Font.BOLD, 16);

}
