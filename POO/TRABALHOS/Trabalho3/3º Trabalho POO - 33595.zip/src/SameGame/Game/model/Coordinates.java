/*
 * ISEL - POO
 * 3º trabalho Semestre Verão 2009/2010
 * 33595 - Nuno Sousa
 */
package SameGame.Game.model;

public class Coordinates{
        private int row;
        private int column;
        public Coordinates(int r, int c){row=r;column=c;}
        public int getRow(){return row;}
        public int getColumn(){return column;}
}
