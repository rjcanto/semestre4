/*
 * ISEL - POO
 * 3º trabalho Semestre Verão 2009/2010
 * 33595 - Nuno Sousa
 */
package SameGame.Game.model;


public interface BlockRule_I {
    public boolean[][] getSelectionRule();
}
