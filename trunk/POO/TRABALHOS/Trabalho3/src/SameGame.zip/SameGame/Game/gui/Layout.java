/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SameGame.Game.gui;

/**
 *
 * @author Nuno
 */
class Layout {

}
