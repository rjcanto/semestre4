/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SameGame.Game.model;

/**
 *
 * @author Nuno
 */
public interface GameModelVars_I {


}
