package SameGame.Game.model;

/**
 *
 * @author Nuno
 */
public class Coordinates{
        private int row;
        private int column;
        public Coordinates(int r, int c){row=r;column=c;}
        public int getRow(){return row;}
        public int getColumn(){return column;}
}
