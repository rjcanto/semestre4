/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SameGame.Game;

import java.util.Observable;

/**
 *
 * @author Nuno
 */
public abstract class SameGameEngineAbstract extends Observable implements SameGameEngine_I{

}
