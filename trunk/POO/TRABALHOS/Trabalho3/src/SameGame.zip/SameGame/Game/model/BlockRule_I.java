/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SameGame.Game.model;

/**
 *
 * @author nac
 */
public interface BlockRule_I {
    public boolean[][] getSelectionRule();
}
