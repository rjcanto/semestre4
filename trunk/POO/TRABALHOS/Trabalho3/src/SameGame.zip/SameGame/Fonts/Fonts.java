/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SameGame.Fonts;

import java.awt.Font;

/**
 *
 * @author nac
 */
public class Fonts{
    public static final Font INFOFONT_LARGE = new Font("Times New Roman", Font.BOLD, 32);
    public static final Font INFOFONT_MEDIUM = new Font("Times New Roman", Font.BOLD, 24);
    public static final Font INFOFONT_SMALL = new Font("Times New Roman", Font.BOLD, 16);



}
