package pt.isel.deetc.ls.cmd;
import pt.isel.deetc.ls.rpt.Report;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class QueryNotOwner extends Report {
	private String _course=null;
	public QueryNotOwner(SQLServerDataSource dts) {
		super("qnot_owner", "Shows the teachers that aren't responsible for any Curricular Unit", dts);
		getParameters().add(new CommandParameter("course",true,"<course_acronym>",false){
			public String getValue() { return _course; }
			public boolean setValue(String p) { _course=p; return true;}
		});
	}
	public void clear() {_course=null;}
	protected String getSelectString() {
		String aux=_course.matches("([a-z]|[A-Z]|[0-9])*")? " AND HCU.acrCurso = '"+_course+"'" : "AND FALSE";
		aux = _course.length()==0? "": aux;
		return "SELECT DISTINCT(DOCENTE.nome) AS 'Nome do Docente' FROM DOCENTE " +
				"where numero not in(" +
				"SELECT numdocente FROM HIST_PROF_UC as HPU inner join HIST_CURSO_UC AS HCU ON (HPU.acrUC = HCU.acrUC) where HPU.anoLectFim IS NULL " + aux + ")";
	}
}
