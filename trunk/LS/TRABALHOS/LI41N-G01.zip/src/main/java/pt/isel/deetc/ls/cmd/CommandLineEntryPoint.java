/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 

/* Based on the examples from MPD */

package pt.isel.deetc.ls.cmd;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import pt.isel.deetc.ls.clp.CommandLineParser;
import pt.isel.deetc.ls.cmd.etapa2.DefaultValues;
import pt.isel.deetc.ls.common.ApplicationExitException;


public class CommandLineEntryPoint {

	private Map<String,Command> _cmds = null;
	private CommandLineParser _clp;
	private DefaultValues _dv;


	public CommandLineEntryPoint(CommandLineParser clp, DefaultValues dv){
		_cmds = new LinkedHashMap<String, Command>();
		_clp = clp;
		_dv=dv;
		this.cmdAdd(new Help()); 	// Presents a list of commands
		this.cmdAdd(new AppExit()); // Exits the application
	}

	public CommandLineEntryPoint(){
		this(new CommandLineParser(), new DefaultValues());
	}

	public void cmdAdd(Command cmd){
		_cmds.put(cmd.getName(), cmd);
	}

	public boolean Execute(String[] args) throws SQLException, IOException {
		StringBuffer sb = new StringBuffer();
		if(args!= null) {
			for (String cmdStr : args) {
				sb.append(cmdStr + " ");
			}
		}
		return Execute(sb.toString());
	}

	// Parses the command line String and uses an Iterator to the parsed Map
	public boolean Execute(String args) throws SQLException, IOException {
		Map<String, String> mapArgs = _clp.parse(args);
		Iterator<String> it = mapArgs.keySet().iterator();
		if(!it.hasNext()) return true;
		String cmdStr=it.next();
		Command cmd = null;
		cmd=_cmds.get(cmdStr);
		if(cmd==null){
			System.out.println("Invalid command");
			return false;
		}
		mapArgs.remove(cmd.getName());
		if(!setParameters(cmd, mapArgs))
			return false;
		cmd.run();
		cmd.clear();
		return true;
	}

	// Pass command line parameters values to commandParameters values 
	private boolean setParameters(Command cmd, Map<String, String> args) {
		cmd.clear();
		for(CommandParameter cp: cmd.getParameters()){
			String v;
			if((v=args.get(cp.getName()))!=null){
				if(!cp.setValue(v))
					return false;
				args.remove(cp.getName());
			}
			else
				if(cp.isMandatory()){
					String val=_dv.getDefault(cp.getName());
					if(val!=null) 
						cp.setValue(val); // Assigns a value to parameter
					else{
						System.out.println("Parameter -"+ cp.getName()+" is mandatory and no default value was found");
						return false;
					}
				}
		}
		if(args.size()!=0){
			StringBuffer sb = new StringBuffer();
			for(String s: args.keySet())
				sb.append("-"+s + " ");
			System.out.println("Unknown parameter(s) found: "+ sb);
			return false;
		}
//		for(CommandParameter cp: cmd.getParameters()){
//			if(cp.isMandatory() && cp.getValue()==null){
//				String val=_dv.getDefault(cp.getName());
//				if(val!=null) 
//					cp.setValue(val); // Assigns a value to parameter
//				else{
//					System.out.println("Parameter -"+ cp.getName()+" is mandatory and no default value was found");
//					return false;
//				}
//			}
//		}
		return true;	
	}

	class Help extends Command{
		public Help(){
			super("help");
		}
		public String getDescription(){
			return "Presents the command directory";
		}
		public void run() throws SQLException{
			for(Command cmd : _cmds.values()){
				System.out.printf("\n%s\n (%s)\n",cmd.usage(), cmd.getDescription());
			}			
		}
		public void clear() {}
		public List<CommandParameter> getParameters() {
			return new ArrayList<CommandParameter>();
		}
	}

	class AppExit extends Command{
		public AppExit(){
			super("exit");
		}
		public String getDescription() {
			return "Exits from application";
		}
		public void run(){
			throw new ApplicationExitException();
		}
		public String usage() {
			return "-"+getName();
		}
		public List<CommandParameter> getParameters() {
			return new ArrayList<CommandParameter>();
		}
		public void clear() {}
	}
}	





