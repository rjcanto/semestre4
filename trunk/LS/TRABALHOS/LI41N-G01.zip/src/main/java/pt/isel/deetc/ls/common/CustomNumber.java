package pt.isel.deetc.ls.common;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
/**
 * 
 * @author Nuno Cancelo
 * Classe que vai processar os tipos num�ricos, tendo em conta as configura��es regionais.
 * 
 */
public class CustomNumber {
	public static final Locale PT_Locale=new Locale("pt","PT");
	
	/**
	 * Metodo que transforma uma string num numero do tipo double. Admite que o Locale � pt-PT.
	 * 
	 * @param strDouble
	 * @return Double
	 * 
	 * <br>Caso n�o seja poss�vel a transforma��o lan�a NumberFormatException.
	 */
	public static Double parseDouble(String strDouble){
		if (strDouble ==  null )throw new NumberFormatException("null");
		return parseDouble(strDouble,PT_Locale);
	}
	/**
	 * Metodo que transforma uma string num numero do tipo double.
	 * 
	 * @param strDouble
	 * @param customLocale
	 * @return Double
	 * 
	 * <br>Caso n�o seja poss�vel a transforma��o lan�a NumberFormatException.
	 */

	public static Double parseDouble(String strDouble, Locale customLocale){
		if (strDouble ==  null )throw new NumberFormatException("null");
		NumberFormat nf=NumberFormat.getNumberInstance(customLocale);
		
		try {

			return nf.parse(strDouble).doubleValue();
		} catch (ParseException e) {
			throw new NumberFormatException("N�o � poss�vel formatar para Double o valor:"+strDouble);
		}	
	}


}
