package pt.isel.deetc.ls.gui.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.sql.Connection;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import pt.isel.deetc.ls.gui.model.ExtendedCurricularUnit;
import pt.isel.deetc.ls.gui.model.ListModel;
import pt.isel.deetc.ls.model.ContactoUC;
import pt.isel.deetc.ls.model.Teacher;

public class UCViewer  extends JPanel{
	private static final long serialVersionUID = 1L;
	Connection _con;
	Teacher _owner;
	JTextField tfName, tfAcron, tfEcts, tfHoursPL, tfHoursOT, tfHoursT, tfHoursTP, tfOwner, tfType;
	JLabel lMsg;
	JCheckBox cbType;

	public UCViewer(ExtendedCurricularUnit uc) {
		setLayout(new BorderLayout());
		ListModel<Teacher> listView=new ListModel<Teacher>(uc.getListTeacher());

		JList tList = new JList(listView);
		tList.setVisibleRowCount(4);
		JScrollPane jspTeacherList = new JScrollPane(tList);
		jspTeacherList.setBorder(new TitledBorder("Teacher List:"));

		jspTeacherList.setSize(jspTeacherList.getSize().width,jspTeacherList.getSize().height/2);
		tList.setCellRenderer(new TCellRenderer());
		
		JPanel jpCourseDetails = new JPanel();
		jpCourseDetails.setLayout(new GridLayout(8,2));
		this.setLayout(new BorderLayout());

		// Acronym field
		JLabel lAcronym = new JLabel("Acronym:");
		lAcronym.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lAcronym);
		tfAcron = new JTextField( uc.getAcronym() );
		tfAcron.setEditable(false);
		jpCourseDetails.add(tfAcron);

		// Name field
		JLabel lName = new JLabel("Name:");
		lName.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lName);
		tfName = new JTextField( uc.getName() );
		tfName.setEditable(false);
		jpCourseDetails.add(tfName);

		// Credits field
		JLabel lCredit = new JLabel("Credits:");
		lCredit.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lCredit);
		tfEcts = new JTextField( Double.toString(uc.getCredits()));
		tfEcts.setEditable(false);
		jpCourseDetails.add(tfEcts);

		// Credits Type
		JLabel lType = new JLabel("Curricular Unit Type:");
		lType.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lType);
		tfType = new JTextField(uc.getElective().compareToIgnoreCase("opcional")==0?"elective":"required");
		tfType.setEditable(false);
		jpCourseDetails.add(tfType);

		// ContactPL field
		JLabel lHPL = new JLabel("Contact Hours PL:");
		lHPL.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lHPL);
		tfHoursPL = new JTextField("0");
		tfHoursPL.setEditable(false);
		jpCourseDetails.add(tfHoursPL);

		// ContactOT field
		JLabel lHoursOT = new JLabel("Contact Hours OT:");
		lHoursOT.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lHoursOT);
		tfHoursOT = new JTextField("0");
		tfHoursOT.setEditable(false);
		jpCourseDetails.add(tfHoursOT);

		// ContactT field
		JLabel lHoursT = new JLabel("Contact Hours T:");
		lHoursT.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lHoursT);
		tfHoursT = new JTextField("0");
		tfHoursT.setEditable(false);
		jpCourseDetails.add(tfHoursT);

		//	ContactTP field
		JLabel lHTP = new JLabel("Contact Hours TP:");
		lHTP.setHorizontalAlignment(SwingConstants.RIGHT);
		jpCourseDetails.add(lHTP);
		tfHoursTP = new JTextField("0");
		tfHoursTP.setEditable(false);
		jpCourseDetails.add(tfHoursTP);

		for(ContactoUC u:uc.getContactList())
			if(u.getType().compareToIgnoreCase("PL")==0)
				tfHoursPL.setText(Double.toString(u.getHours()));
			else if(u.getType().compareToIgnoreCase("OT")==0)
				tfHoursOT.setText(Double.toString(u.getHours()));				
			else if(u.getType().compareToIgnoreCase("T")==0)
				tfHoursT.setText(Double.toString(u.getHours()));					
			else if(u.getType().compareToIgnoreCase("TP")==0)
				tfHoursTP.setText(Double.toString(u.getHours()));	

		this.add(jpCourseDetails,BorderLayout.NORTH);
		this.add(jspTeacherList,BorderLayout.CENTER);
	}
	public class TCellRenderer extends JLabel implements ListCellRenderer{

		private static final long serialVersionUID = 1L;
		public TCellRenderer() {
			setOpaque(true);
		}
		@Override
		public Component getListCellRendererComponent(
				JList list,
				Object value,
				int index,
				boolean isSelected,
				boolean cellHasFocus)
		{
			Teacher t= (Teacher) value;
			setText(t.getNOME() +"( "+t.getEMAIL()+" )");
			setBackground(isSelected ? Color.blue : new Color(0xFFFFFF));
			return this;
		}
	}
}