package pt.isel.deetc.ls.gui.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.gui.model.ExtendedCurricularUnit;
import pt.isel.deetc.ls.gui.model.ListModel;
import pt.isel.deetc.ls.mapper.ContactoUCMapper;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.model.ContactoUC;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;


public class UCEditor extends JPanel{
	private static final long serialVersionUID = 1L;
	
    private final SQLServerDataSource _dts;
	ExtendedCurricularUnit _uc;
	Course _course;
	Teacher _owner;
	Semester _semester;
	JTextField tfName, tfAcron, tfEcts, tfHoursPL, tfHoursOT, tfHoursT, tfHoursTP, tfOwner;
	JLabel lMsg;
	JCheckBox cbType;
	

	public UCEditor(ExtendedCurricularUnit uc) {
		super();
		_uc=uc;
		_dts=null;
		JButton bt = new JButton("Update");
		bt.setVisible(true);
		bt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					updateUC();
				} catch (NumberFormatException e1) {
					e1.printStackTrace();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		createPanel(bt);
	}

	public UCEditor(SQLServerDataSource dts, final JList jl, final Course c, final Semester s) {
		super();
		_dts = dts;
		final int idx=jl.getSelectedIndex();
		_course=c;
		_semester=s;
		_uc= (ExtendedCurricularUnit) jl.getModel().getElementAt(idx);
		if(idx==-1)
			return;

		JButton bt = new JButton("Update");
		bt.setVisible(true);
		bt.addActionListener(new ActionListener() {
			@SuppressWarnings("unchecked")
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					updateUC();
					ExtendedCurricularUnit ecu = (ExtendedCurricularUnit) jl.getModel().getElementAt(idx);
					ListModel<ExtendedCurricularUnit> jlm = (ListModel<ExtendedCurricularUnit>) jl.getModel();
					if(updateUCDB(_dts, ecu, _uc)){ 
						jlm.remove(idx);
						jlm.add(idx, _uc);
					}
				} catch (NumberFormatException e1) {
					e1.printStackTrace();
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (BadParameterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		createPanel(bt);
	}

	
	
		
	private void createPanel(JButton bt){
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(8,2));
		this.setLayout(new BorderLayout());

		// Acronym field
		JLabel lAcronym = new JLabel("Acronym:");
		lAcronym.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lAcronym);
		tfAcron = new JTextField( _uc.getAcronym() );
		tfAcron.setEditable(true);
		jp.add(tfAcron);

		// Name field
		JLabel lName = new JLabel("Name:");
		lName.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lName);
		tfName = new JTextField( _uc.getName() );
		tfName.setEditable(true);
		jp.add(tfName);

		// Credits field
		JLabel lCredit = new JLabel("Credits:");
		lCredit.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lCredit);
		tfEcts = new JTextField( Double.toString(_uc.getCredits()));
		tfEcts.setEditable(true);
		jp.add(tfEcts);
		
		// ContactPL field
		JLabel lHPL = new JLabel("Contact Hours PL:");
		lHPL.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lHPL);
		tfHoursPL = new JTextField( );
		tfHoursPL.setEditable(true);
		jp.add(tfHoursPL);
		tfHoursPL.setText("0");
		
		// ContactPL field
		JLabel lHoursOT = new JLabel("Contact Hours OT:");
		lHoursOT.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lHoursOT);
		tfHoursOT = new JTextField( );
		tfHoursOT.setEditable(true);
		jp.add(tfHoursOT);
		tfHoursOT.setText("0");
		
		// ContactT field
		JLabel lHoursT = new JLabel("Contact Hours T:");
		lHoursT.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lHoursT);
		tfHoursT = new JTextField( );
		tfHoursT.setEditable(true);
		jp.add(tfHoursT);
		tfHoursT.setText("0");
		
		//	ContactTP field
		JLabel lHTP = new JLabel("Contact Hours TP:");
		lHTP.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lHTP);
		tfHoursTP = new JTextField( );
		tfHoursTP.setEditable(true);
		jp.add(tfHoursTP);
		tfHoursTP.setText("0");
		
		for(ContactoUC u:_uc.getContactList())
			if(u.getType().compareToIgnoreCase("PL")==0)
				tfHoursPL.setText(Double.toString(u.getHours()));
			else if(u.getType().compareToIgnoreCase("OT")==0)
				tfHoursOT.setText(Double.toString(u.getHours()));				
			else if(u.getType().compareToIgnoreCase("T")==0)
				tfHoursT.setText(Double.toString(u.getHours()));					
			else if(u.getType().compareToIgnoreCase("TP")==0)
				tfHoursTP.setText(Double.toString(u.getHours()));	

		// Type
		boolean required=_uc.getElective().compareToIgnoreCase("opcional")!=0;
		cbType = new JCheckBox( "Required", required );
		cbType.setEnabled(true);
		jp.add(cbType);
		
		this.add(jp,BorderLayout.CENTER);
		this.add(bt,BorderLayout.SOUTH);

	}	

	private void updateUC() throws NumberFormatException, SQLException {

		_uc.setAcronym(tfAcron.getText());
		_uc.setName(tfName.getText());
		_uc.setEcts(Double.valueOf(tfEcts.getText()));
		_uc.setContactList(new LinkedList<ContactoUC>());
		_uc.getContactList().add(new ContactoUC(Double.valueOf(tfHoursPL.getText()), "PL", tfAcron.getText()));
		_uc.getContactList().add(new ContactoUC(Double.valueOf(tfHoursOT.getText()), "OT", tfAcron.getText()));
		_uc.getContactList().add(new ContactoUC(Double.valueOf(tfHoursT.getText()), "T", tfAcron.getText()));
		_uc.getContactList().add(new ContactoUC(Double.valueOf(tfHoursTP.getText()), "TP", tfAcron.getText()));
		_uc.setElective( cbType.getSelectedObjects()!=null?"obrigat�rio":"opcional" );
	}	

	
	private boolean updateUCDB(SQLServerDataSource dts, ExtendedCurricularUnit ecuInicial, ExtendedCurricularUnit ecuFinal) throws SQLException, BadParameterException{
		Connection con=dts.getConnection();
		ContactoUCMapper cucm= 	new ContactoUCMapper(con);
		CurricularUnitMapper ucm = new CurricularUnitMapper(con); 
		if(!ecuInicial.equals(ecuFinal))
			ucm.update(ecuInicial.getAcronym(), ecuFinal.getUC());
		for(ContactoUC cuc: ecuFinal.getContactList()){
			int n=cucm.update(cuc);
			if(n==0)
				cucm.insert(cuc);
		}
		ucm.updateUCCourse(_course, _uc.getUC(), _semester, _uc.getSemCurr(), _uc.getElective());
		return true;
	}
}


