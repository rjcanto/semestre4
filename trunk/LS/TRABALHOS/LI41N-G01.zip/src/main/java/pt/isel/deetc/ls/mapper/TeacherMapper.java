package pt.isel.deetc.ls.mapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

public class TeacherMapper extends Mapper<Teacher>{
	
	public TeacherMapper(Connection c){
		super(c);
	}
	
	@Override
	public int delete(Teacher t) throws SQLException {
		return 0;
	}
	
	public int delete(Teacher t, Semester s) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		String updateHistDocUC = "UPDATE HIST_DOC_UC SET HIST_DOC_UC.anoLectFim=?, HIST_DOC_UC.semLectFim=?" +
		" WHERE DOCENTE.numero=? AND HIST_DOC_UC.anoLectFim IS NULL";
	String updateHistProfCurso = "UPDATE HIST_PROF_CURSO SET "+
		"HIST_PROF_CURSO.anoLectFim=?, HIST_PROF_CURSO.semLectFim=?" +
		"WHERE HIST_PROF_CURSO.numDocente=? AND HIST_PROF_CURSO.anoLectFim IS NULL;" ;
	String updateHistProfUC = "UPDATE HIST_PROF_UC SET "+
		"HIST_PROF_UC.anoLectFim=?, HIST_PROF_UC.semLectFim=? " +
		"WHERE HIST_PROF_UC.numDocente=? AND HIST_PROF_UC.anoLectFim IS NULL;" ;
		try{
			_c.setAutoCommit(false);
			PreparedStatement stmtHistDocUC=_c.prepareStatement(updateHistDocUC);
			stmtHistDocUC.setString(1, s.getYear());
			stmtHistDocUC.setString(2, s.getSeason());
			stmtHistDocUC.setInt(3, t.getNBRMEC()) ;
			stmtHistDocUC.executeUpdate();
			
			PreparedStatement stmtHistProfCurso=_c.prepareStatement(updateHistProfCurso);
			stmtHistProfCurso.setString(1, s.getYear());
			stmtHistProfCurso.setString(2, s.getSeason());
			stmtHistProfCurso.setInt(3, t.getNBRMEC()) ;
			stmtHistProfCurso.executeUpdate();
			
			PreparedStatement stmtHistProfUC=_c.prepareStatement(updateHistProfUC);
			stmtHistProfUC.setString(1, s.getYear());
			stmtHistProfUC.setString(2, s.getSeason());
			stmtHistProfUC.setInt(3, t.getNBRMEC()) ;
			stmtHistProfUC.executeUpdate();
			
			_c.commit() ;
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}

	@Override
	public int insert(Teacher d) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("INSERT INTO DOCENTE "+
					"(numero, nome, email, tipo) values (?,?,?,?)") ;
			statement.setInt(1, d.getNBRMEC()) ;
			statement.setString(2, d.getNOME()) ;
			statement.setString(3, d.getEMAIL()) ;
			statement.setString(4, d.getTIPO()) ;
			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	@Override
	public int update(Teacher d) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		try{
			statement = _c.prepareStatement("UPDATE DOCENTE SET "+
					"DOCENTE.nome=?, DOCENTE.email=?,DOCENTE.tipo=? WHERE DOCENTE.numero=?") ;
			statement.setString(1, d.getNOME()) ;
			statement.setString(2, d.getEMAIL()) ;
			statement.setString(3, d.getTIPO()) ;
			statement.setInt(4, d.getNBRMEC()) ;
			nUpdated=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}
	
	public int update(int nTeacher, Teacher d) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		try{
			statement = _c.prepareStatement("UPDATE DOCENTE SET "+
					"DOCENTE.numero=?, DOCENTE.nome=?, DOCENTE.email=?," +
					"DOCENTE.tipo=? WHERE DOCENTE.numero=?") ;
			statement.setInt(1, d.getNBRMEC()) ;
			statement.setString(2, d.getNOME()) ;
			statement.setString(3, d.getEMAIL()) ;
			statement.setString(4, d.getTIPO()) ;
			statement.setInt(5, nTeacher) ;
			nUpdated=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}
	
	@Override
	public List<Teacher> select() throws SQLException {
		PreparedStatement statement=null;
		List<Teacher> list = new LinkedList<Teacher>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT DOCENTE.numero, DOCENTE.nome, DOCENTE.email, DOCENTE.tipo "+
					"FROM DOCENTE") ;
			rs=statement.executeQuery();
			while(rs.next()) {
				list.add(new Teacher(rs.getInt("numero"),rs.getString("nome"),
						rs.getString("email"),rs.getString("tipo"))) ;
			}
			return list;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	
	public Teacher selectNumber(int numTeacher) throws SQLException {
		PreparedStatement statement=null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT DOCENTE.numero, DOCENTE.nome, DOCENTE.email, DOCENTE.tipo "+
					"FROM DOCENTE WHERE DOCENTE.numero=?") ;
			statement.setInt(1, numTeacher) ;
			rs=statement.executeQuery();
			if (rs.next())
				return new Teacher(rs.getInt("numero"),rs.getString("nome"),
						rs.getString("email"),rs.getString("tipo")) ;
			return null ;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	public List<Teacher> selectName(String nameTeacher) throws SQLException {
		PreparedStatement statement=null;
		List<Teacher> resultList = new LinkedList<Teacher>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT DOCENTE.numero, DOCENTE.nome, DOCENTE.email, DOCENTE.tipo "+
					"FROM DOCENTE WHERE DOCENTE.nome=?") ;
			statement.setString(1, nameTeacher.toLowerCase()) ;
			rs=statement.executeQuery();
			while (rs.next())
				resultList.add(new Teacher(rs.getInt("numero"),rs.getString("nome"),
						rs.getString("email"),rs.getString("tipo"))) ;
			return resultList ;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}

	public List<Teacher> selectEmail(String emailTeacher) throws SQLException {
		PreparedStatement statement=null;
		List<Teacher> resultList = new LinkedList<Teacher>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT DOCENTE.numero, DOCENTE.nome, DOCENTE.email, DOCENTE.tipo "+
					"FROM DOCENTE WHERE DOCENTE.email=?") ;
			statement.setString(1, emailTeacher.toLowerCase()) ;
			rs=statement.executeQuery();
			while (rs.next())
				resultList.add(new Teacher(rs.getInt("numero"),rs.getString("nome"),
						rs.getString("email"),rs.getString("tipo"))) ;
			return resultList ;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	public List<Teacher> selectType(String typeTeacher) throws SQLException {
		PreparedStatement statement=null;
		List<Teacher> resultList = new LinkedList<Teacher>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT DOCENTE.numero, DOCENTE.nome, DOCENTE.email, DOCENTE.tipo "+
					"FROM DOCENTE WHERE DOCENTE.tipo=?") ;
			statement.setString(1, typeTeacher.toLowerCase()) ;
			rs=statement.executeQuery();
			while (rs.next())
				resultList.add(new Teacher(rs.getInt("numero"),rs.getString("nome"),
						rs.getString("email"),rs.getString("tipo"))) ;
			return resultList ;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	@Override
	public boolean find(Teacher t) throws SQLException {
		PreparedStatement statement=null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT DOCENTE.numero, DOCENTE.nome, DOCENTE.email, DOCENTE.tipo "+
					"FROM DOCENTE WHERE DOCENTE.numero=?") ;
			statement.setInt(1, t.getNBRMEC()) ;
			rs=statement.executeQuery();
			if(rs.next())
				return true;
			return false;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
}
