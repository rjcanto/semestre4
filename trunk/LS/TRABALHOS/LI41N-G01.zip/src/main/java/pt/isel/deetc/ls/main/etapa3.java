/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 
package pt.isel.deetc.ls.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.sql.SQLException;

import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.ApplicationExitException;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.clp.CommandLineParser;
import pt.isel.deetc.ls.cmd.*;
import pt.isel.deetc.ls.cmd.etapa1.*;
import pt.isel.deetc.ls.cmd.etapa2.*;
import pt.isel.deetc.ls.cmd.etapa3.QCourse;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class etapa3 {
	
//	private static ViewMode vm = new TextView();
//	private static PrintStream fout = System.out;
	
	static UpdateUC _uuc;
	
	public static void main(String[] args) {
		
			try {
				
				final ApplicationDB appDB = new ApplicationDB();

				final DefaultValues _dv = new DefaultValues();				
				final CommandLineEntryPoint cmd = new CommandLineEntryPoint(new  CommandLineParser(), _dv);

				SQLServerDataSource dts = appDB.getDataSource();
				
				// add commands to the execution directory (map)  
				cmd.cmdAdd(new SetDefault(_dv));

				cmd.cmdAdd(new LoadDBTest(dts));
				
				cmd.cmdAdd(new AddTeacherToUC(dts));
				cmd.cmdAdd(new AssociateUCCourse(dts));
				cmd.cmdAdd(new ChangeUCReponsible(dts));
				cmd.cmdAdd(new CreateCourse(dts));
				cmd.cmdAdd(new CreateDB(dts));
				cmd.cmdAdd(new ExtractDBData(dts));
				cmd.cmdAdd(new GenerateDBSchema(dts));
				cmd.cmdAdd(new LoadDBData(dts));
				cmd.cmdAdd(new QueryNotOwner(dts));
				cmd.cmdAdd(new QueryUC_Owners(dts));
				cmd.cmdAdd(new QueryUC(dts));
				cmd.cmdAdd(new QueryOwners(dts));
				cmd.cmdAdd(new RemoveOwner(dts));
				cmd.cmdAdd(new RemoveTeacherFromUC(dts));
				cmd.cmdAdd(new RemoveUC(dts));
				cmd.cmdAdd(new RemoveUC(dts));
				cmd.cmdAdd(new UpdateTeacher(dts));
				cmd.cmdAdd(_uuc=new UpdateUC(dts));
				cmd.cmdAdd(new UpdateUCOwner(dts));
				cmd.cmdAdd(new QCourse(dts));

				if(args.length==0){
					BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
					while(true){
						System.out.print("# ");
						try{
							if(!cmd.Execute(in.readLine()))
								System.out.println("Command not executed");
						}
						catch (SQLException e) {
							Utils.writeUserError("Database fault", e.getMessage());
						} catch (IOException e) {
							Utils.writeUserError("Read/Write operation failed", e.getMessage());
						}
					}
				}
				else
					try{
						if(!cmd.Execute(args))
							System.out.println("Command not executed");
					}
					catch (SQLException e) {
						Utils.writeUserError("Database fault", e.getMessage());
					} catch (IOException e) {
						Utils.writeUserError("Read/Write operation failed", e.getMessage());
					}

			}
			catch (ApplicationExitException e) {
				System.exit(0);
			}
	}
	static public UpdateUC getUUCCmd(){
		return _uuc;
	}
}
