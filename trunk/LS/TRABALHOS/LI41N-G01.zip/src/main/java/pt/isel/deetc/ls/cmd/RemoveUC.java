package pt.isel.deetc.ls.cmd;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;


public class RemoveUC extends Command{
	private String _uc;
	private String _course;
	private String _semSeason;
	private String _semYear;


	public RemoveUC(SQLServerDataSource dts) {
		super("ruc", "Removes a Curricular Unit from a Course", dts);
		getParameters().add(new CommandParameter("uc",true, "<uc_acronym>", false){
			public String getValue() { return _uc; }
			public boolean setValue(String p) { _uc=p; return true; }
		});
		getParameters().add(new CommandParameter("course",true, "<course_acronym>", false){
			public String getValue() { return _course; }
			public boolean setValue(String p) {	_course=p; return true; }
		});
		getParameters().add(new CommandParameter("sems",true, "<semester_season>", false){
			public String getValue() { return _semSeason; }
			public boolean setValue(String p) { _semSeason=p; return true; }
		});
		getParameters().add(new CommandParameter("semy",true, "<year_year>", false){
			public String getValue() { return _semYear; }
			public boolean setValue(String p) { _semYear=p; return true; }
		});
		}

	public void setUC(String uc) { _uc=uc;}
	public void setCourse(String c){ _course=c;}
	public void setSemLect(String s ){ _semSeason=s;}
	public void setYearLect(String y){_semYear=y;}

	
	@Override
	public void clear() {
		_uc=null;
		_course=null;
		_semSeason=null;
		_semYear=null;
	}

	@Override
	public void run() throws SQLException, FileNotFoundException, IOException {
		Connection conn =  getDts().getConnection();
		CourseMapper com = new CourseMapper(conn );
		Course co;
		CurricularUnit cu;
		Semester se;
		if((co=com.selectAcronim(_course))==null){
			Utils.writeUserError("Invalid Course Acronym", "Please use a valid Acronym");
			return;
		}
		CurricularUnitMapper cum = new CurricularUnitMapper( conn );

		if((cu=cum.selectAcronimo(_uc))==null){
			Utils.writeUserError("Invalid UC Acronym", "Please use a valid UC Acronym");
			return;
		}
		try{
			SemesterMapper sem = new SemesterMapper( conn ); 
			if((se = sem.selectSem(_semYear, _semSeason ))==null){
				Utils.writeUserError("Invalid Lective Year or Semester", "Please review parameters");
				return;
			}
		}
		catch(BadParameterException e){
			Utils.writeUserError("Invalid parameter", "Please verify parameters");
			clear();
			if(conn!=null)
				conn.close();
			return;
		}
		cum.delete(cu, co, se);
		clear();
		if(conn!=null)
			conn.close();
	}
}
