package pt.isel.deetc.ls.model;

public class CurricularUnit {
	private String _name;
	private String _acronym;
	private double _credits;
	
	public CurricularUnit(String acronym, String name, double credits){
		this._name=name;
		this._acronym=acronym;
		this._credits=credits;
	}

	public String getName() {
		return _name;
	}

	public String getAcronym() {
		return _acronym;
	}

	public double getCredits() {
		return _credits;
	}

	public void setName(String n) {
		_name=n;
	}

	public void setAcronym(String a) {
		_acronym=a;
	}

	public void setEcts(Double c) {
		_credits=c;
	}
	
	public boolean validateType(String type) {
		return (type.equalsIgnoreCase("opcional") || type.equalsIgnoreCase("obrigat�rio"))?true:false ;
	}
	
	@Override
	public String toString() {
		return "Acronym:"+_acronym+" - Name:"+_name+" - Credits:"+_credits;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) 
			return false;
		
		if(obj.getClass() != getClass()){
			return false;
		}
		
		CurricularUnit c = (CurricularUnit) obj ;
		if (c._acronym.compareToIgnoreCase(this._acronym)==0)
			return true ;
		return false ;
	}

	@Override
	public int hashCode(){
		return _acronym.hashCode();
	}
	
}
