package pt.isel.deetc.ls.mapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.model.Semester;

public class SemesterMapper extends Mapper<Semester> {

	public SemesterMapper(Connection c) {
		super(c);
	}

	@Override
	public int delete(Semester t) throws SQLException {
		PreparedStatement statement=null;
		int nDeleted=0;
		try{
			String cmdDelete = "DELETE FROM SEMLECTIVO "+ 
				"WHERE SEMLECTIVO.anoLectivo = ? AND SEMLECTIVO.semLectivo = ?" ;
			statement = _c.prepareStatement(cmdDelete) ;
			statement.setString(1, t.getYear()) ;
			statement.setString(2, t.getSeason()) ;
			nDeleted=statement.executeUpdate(); //TODO - manage a delete fault (because the constraints ....)
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nDeleted;
	}

	@Override
	public int insert(Semester t) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("INSERT INTO SEMLECTIVO "+
					"(anoLectivo, semLectivo, dataInicio, dataFim) values (?,?,?,?)") ;
			statement.setString(1, t.getYear()) ;
			statement.setString(2, t.getSeason()) ;
			statement.setDate(3, t.getBegin()) ;
			statement.setDate(4, t.getEnd()) ;
			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	@Override
	/**
	 * Updates a beginning and ending date for a semester.
	 */
	public int update(Semester t) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		try{
			statement = _c.prepareStatement("UPDATE SEMLECTIVO SET "+
					"SEMLECTIVO.dataInicio=? ,SEMLECTIVO.dataFim=? "+ 
					"WHERE SEMLECTIVO.anoLectivo=? AND SEMLECTIVO.semLectivo=?") ;
			statement.setDate(1, t.getBegin()) ;
			statement.setDate(2, t.getEnd()) ;
			statement.setString(3, t.getYear()) ;
			statement.setString(4, t.getSeason()) ;
			nUpdated=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}

	@Override
	public boolean find(Semester t) throws SQLException {
		PreparedStatement statement = null ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT SEMLECTIVO.anoLectivo, SEMLECTIVO.semLectivo "+
					"FROM SEMLECTIVO WHERE SEMLECTIVO.anoLectivo=? AND SEMLECTIVO.semLectivo=?") ;
			statement.setString(1, t.getYear()) ;
			statement.setString(2, t.getSeason()) ;
			rs=statement.executeQuery() ;
			if(rs.next())
				return true ;
			return false ;
		}finally{
			if(statement!=null)
				statement.close() ;
		}
	}

	public List<Semester> select() throws SQLException {
		// TODO Implement SemesterMapper.select
		return null;
	}
	
	public Semester selectSem(String year, String season) throws SQLException, BadParameterException {
		PreparedStatement statement=null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement(
					"SELECT SEMLECTIVO.anoLectivo, SEMLECTIVO.semLectivo," +
					" SEMLECTIVO.dataInicio, SEMLECTIVO.dataFim"+
					" FROM SEMLECTIVO " +
					"WHERE SEMLECTIVO.anoLectivo=? AND SEMLECTIVO.semLectivo=?") ;
			statement.setString(1, year) ;
			statement.setString(2, season) ;
			rs=statement.executeQuery();
			while(rs.next()) {
				return(new Semester(
						rs.getString("anoLectivo"),
						rs.getString("semLectivo"),
						rs.getDate("dataInicio"),
						rs.getDate("dataFim"))) ;
			}
			return null;
		}finally{
			if(statement!=null) 
				statement.close();
		}
	}
}
