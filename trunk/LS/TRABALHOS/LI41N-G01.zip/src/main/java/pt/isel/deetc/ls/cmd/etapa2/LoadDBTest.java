package pt.isel.deetc.ls.cmd.etapa2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.common.Utils;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public class LoadDBTest extends Command {

	private Connection _con=null;
	
	public LoadDBTest(SQLServerDataSource dts){
		super("ld_test","Loads testing data", dts);
	}

	public void connect() throws SQLServerException{
		_con=getDts().getConnection();
	}
	public void disconnect() throws SQLException{
		_con.close();
	}

	public void run() throws SQLException, IOException{
		
		try{
			connect();
			runSQLFile("_PopulateTables.sql");
		}
		catch(SQLException e){
			Utils.writeUserError("Database fault", "Probably due to an insert key violation");

		}
		finally{
			disconnect();			
		}

	}

	private void DDLExec(String sqlStat) throws SQLException {
		Statement stmt = _con.createStatement();
		stmt.executeUpdate(sqlStat);
		stmt.close();
	}

	/*
	 * The SQL file that supports this method, shall include a ";" string after each 
	 * DDL command, otherwise, the statement that does not finishes with a ";" will not
	 * be execute, and can generate a SQL error.
	 */
	private void runSQLFile(String str) throws SQLException, IOException {
		BufferedReader in = null;
		InputStream is = ClassLoader.getSystemResourceAsStream(str);
		if(is==null){
			System.err.println("Error on opening or reading "+str+" file.");
			return;
		}
		in =  new BufferedReader(new InputStreamReader(is));
		String line;
		StringBuffer sb=new StringBuffer();
		while((line=in.readLine())!=null){
			sb.append(line+" ");
			if(line.contains(";")){
				DDLExec(sb.toString());
				sb=new StringBuffer();
			}
		}
	}

	@Override
	public void clear() {}
}
