/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 

package pt.isel.deetc.ls.cmd.etapa3;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;

import java.util.List;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.gui.model.ExtendedCurricularUnit;
import pt.isel.deetc.ls.gui.model.ListModel;
import pt.isel.deetc.ls.gui.view.CourseView;
import pt.isel.deetc.ls.gui.view.Launch;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class QCourse extends Command {
	private String _course;
	private String _semYear;
	private String _semSeason;


	public void setCourse(String c){
		_course=c;
	}
	public void setSemYear(String sYear){
		_semYear=sYear;
	}
	public void setSemSeason(String sSeason){
		_semSeason=sSeason;
	}
	
	public QCourse( SQLServerDataSource dts ) {
		super( "qcourse", "Query curricular plan for a course.", dts );
		getParameters( ).add( new CommandParameter( "course",true,"<course>",false ) {
			public String getValue( ) { return _course; }
			public boolean setValue( String p ) { _course = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "year",true,"<semester_year>",false ) {
			public String getValue( ) { return _semYear; }
			public boolean setValue( String p ) { _semYear = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "season",true,"<semester_season>",false ) {
			public String getValue( ) { return _semSeason; }
			public boolean setValue( String p ) { _semSeason = p; return true;}
		} );
	}


	//	"-qcourse [-course <acr>] [-season <season_name> -year <year>] ";


	@Override
	public void clear( ) {
		_semSeason=null;
		_semYear=null;
		_course=null;
	}
	
	

	
	public void run( ) throws SQLException{

		Connection con=null;
		int nUpdates = 0;
		try{
			con = getDts( ).getConnection( );
			CourseMapper cm = new CourseMapper(con);
			SemesterMapper sm = new SemesterMapper(con);
			Course c=cm.selectAcronim(_course);
			Semester s = sm.selectSem(_semYear, _semSeason);
			List<ExtendedCurricularUnit> l=cm.selectUC(c,s);
			Teacher t= cm.selectOwner(c, s);
//			System.out.println("l.size()="+l.size());
			try {
				Launch.lauchDialog(new CourseView(getDts(), c, s, t, new ListModel<ExtendedCurricularUnit>(l)),true, "Course Browser", true);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
		
		} catch (BadParameterException e) {
			Utils.writeUserError("Invalid Parameter", e.getMessage());
		}
		finally{
			if(con!=null)
				con.close();
			if ( nUpdates > 0 )
				System.out.println( "Successful update." );
			clear();
		}
	}

}