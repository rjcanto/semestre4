package pt.isel.deetc.ls.cmd.etapa2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class AddTeacherToUC extends Command{
	private String _tn,_uc,_sm,_year;
	public AddTeacherToUC(SQLServerDataSource dts) {
		super("add_teacher", "Add a Teacher to a Curricular Unit on a Semester", dts);
		clear();
		getParameters().add(new CommandParameter("tn",true,"<teacher_number>",false){
			public String getValue() { return _tn; }
			public boolean setValue(String p) { _tn=p; return true; }
		});
		getParameters().add(new CommandParameter("uc",true,"<uc_acronym>",false){
			public String getValue() { return _uc; }
			public boolean setValue(String p) { _uc=p; return true; }
		});
		getParameters().add(new CommandParameter("season",true,"<semester_season>",false){
			public String getValue() { return _sm; }
			public boolean setValue(String p) { _sm=p; return true; }
		});
		getParameters().add(new CommandParameter("year",true,"<Semester_year>",false){
			public String getValue() { return _year; }
			public boolean setValue(String p) { _year=p; return true; }
		});
	}
	
	public void setUC(String uc){
		_uc=uc;
	}
	public void setSeason(String sm){
		_sm=sm;
	}
	public void setYear(String year){
		_year=year;
	}
	public void setTeacher(String tn){
		_tn=tn;
	}


	@Override
	public void clear() { _tn=_uc=_year=_sm=null;}

	@Override
	public void run() throws SQLException, FileNotFoundException, IOException {
		Connection conn =  getDts().getConnection();
		TeacherMapper tMapper = new TeacherMapper(conn) ;
		Teacher t=tMapper.selectNumber(Integer.parseInt(_tn.trim()));
		CurricularUnitMapper cm=new CurricularUnitMapper(conn);
		CurricularUnit c=cm.selectAcronimo(_uc);
		Semester s ;
		try{
			s=(new SemesterMapper(conn)).selectSem(_year, _sm);
		}
		catch(BadParameterException e){
			Utils.writeUserError("Invalid Year or Season", "Please verify Semester Year or Season");
			clear();
			if(conn!=null)
				conn.close();
			return;
		}
		cm.insertTeacherInUc(c, t, s);
		clear();
		if(conn!=null)
			conn.close();
	}
}
