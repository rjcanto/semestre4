/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 

package pt.isel.deetc.ls.cmd.etapa1;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.gui.model.ExtendedCurricularUnit;
import pt.isel.deetc.ls.gui.view.Launch;
import pt.isel.deetc.ls.gui.view.UCEditor;
import pt.isel.deetc.ls.mapper.ContactoUCMapper;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.model.ContactoUC;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.Semester;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class UpdateUC extends Command {
	private String _uc;
	private String _acr;
	private String _req;
	private String _ects;
	private String _name;
	private String _owner;
	private String _course;
	private String _currSem;
	private String _semYear;
	private String _semSeason;
	private String _gui;

	public void setCourse(String c){
		_course=c;
	}
	public void setSemYear(String sYear){
		_semYear=sYear;
	}
	public void setSemSeason(String sSeason){
		_semSeason=sSeason;
	}
	public void setUC(String u){
		_uc=u;
	}
	public void setAcr(String a){ 
		_acr=a;
	}
	public void setReq(String r){
		_req=r;
	}
	public void setEcts(String e){
		_ects=e;
	}
	public void setName(String n){
		_name=n;
	}
	public void setOwner(String o){
		_owner=o;
	}
	public void setCurrSemester(String cs){
		_currSem=cs;
	}

	public UpdateUC( SQLServerDataSource dts ) {
		super( "uuc", "Updates Curricular Unit UC details.", dts );
		getParameters( ).add( new CommandParameter( "uc",true,"<acronim>",false ) {
			public String getValue( ) { return _uc; }
			public boolean setValue( String p ) { _uc = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "gui",false,"",false ) {
			public String getValue( ) { return _gui; }
			public boolean setValue( String p ) { _gui = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "acr",false,"<newValue>",false ) {
			public String getValue( ) { return _acr; }
			public boolean setValue( String p ) { _acr = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "type",false,"<newValue(elective|required)>",false ) {
			public String getValue( ) { return _req; }
			public boolean setValue( String p ) { 
				_req = p.compareToIgnoreCase("required")==0? "obrigat�rio":"opcional";
				return true;}
		} );
		getParameters( ).add( new CommandParameter( "ects",false,"<newValue>",false ) {
			public String getValue( ) { return _ects; }
			public boolean setValue( String p ) { _ects = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "name",false,"<newValue>",false ) {
			public String getValue( ) { return _name; }
			public boolean setValue( String p ) { _name = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "owner",false,"<newValue>",false ) {
			public String getValue( ) { return _owner; }
			public boolean setValue( String p ) { _owner = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "course",true,"<course>",false ) {
			public String getValue( ) { return _course; }
			public boolean setValue( String p ) { _course = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "currSem",false,"<curricular_semester>",false ) {
			public String getValue( ) { return _currSem; }
			public boolean setValue( String p ) { _currSem = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "year",true,"<semester_year>",false ) {
			public String getValue( ) { return _semYear; }
			public boolean setValue( String p ) { _semYear = p; return true;}
		} );
		getParameters( ).add( new CommandParameter( "season",true,"<semester_season>",false ) {
			public String getValue( ) { return _semSeason; }
			public boolean setValue( String p ) { _semSeason = p; return true;}
		} );
	}


	//	"-uuc -uc <acr> ( -gui | ( -acr | -req | -ects | -name | -owner ) <new-value> )+";


	@Override
	public void clear( ) {
		_uc=null;
		_acr=null;
		_req=null;
		_ects=null;
		_name=null;
		_owner=null;
		_gui=null;
		_semSeason=null;
		_semYear=null;
		_course=null;
		_currSem=null;
	}

	public void run( ) throws SQLException{

		Connection con=null;
		int nUpdates = 0;
		Semester s=null;
		Course c=null;
		try{

			con = getDts( ).getConnection( );
			CourseMapper cm = new CourseMapper(con);
			SemesterMapper sm = new SemesterMapper(con);
			ContactoUCMapper cucm= 	new ContactoUCMapper(con);
			s=sm.selectSem(_semYear, _semSeason);
			c=cm.selectAcronim(_course);
			ExtendedCurricularUnit uc=cm.selectUcByAcr(_uc, c,	s);
			if(uc==null){
				System.out.println("Non existent Curricular Unit");
			}
			else{
				CurricularUnitMapper ucm = new CurricularUnitMapper(con);
				if(_gui!=null){
					try {
						Launch.lauchDialog(new UCEditor(uc), true, "CurricularUnit Editor",true);
						_req=uc.getElective();
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					}
				}
				else{
					if(_acr!=null)
						uc.setAcronym(_acr);
					if(_ects!=null)
						uc.setEcts(Double.valueOf(_ects));
					if(_name!=null)
						uc.setName(_name);
					if(_currSem!=null) {
						String req = cm.selectType(c, uc.getUC());

						if(_semYear==null || _semSeason==null || (s == null)){
							Utils.writeUserError("Semester", "Invalid semester");
							return;
						}
						nUpdates+=ucm.updateUCCourse(c, uc.getUC(), s,(new Integer(_currSem)).intValue(), req);
					}
				}
				for(ContactoUC cuc: uc.getContactList()){
					int n=cucm.update(cuc);
					if(n==0)
						cucm.insert(cuc);
				}
				if(_req != null ){
					if(_semYear==null || _semSeason==null || (s ==null)){
						Utils.writeUserError("Semester", "Invalid semester");
						return;
					}
					int currSem = cm.selectCurrSemester(c, uc.getUC());
					nUpdates+=ucm.updateUCCourse(c, uc.getUC(), s, currSem, _req);
				}
				nUpdates+=ucm.update(_uc, uc.getUC());
			}	
		} catch (BadParameterException e) {
			e.printStackTrace() ;
		}finally{
			if(con!=null)
				con.close();
		}
	}

}