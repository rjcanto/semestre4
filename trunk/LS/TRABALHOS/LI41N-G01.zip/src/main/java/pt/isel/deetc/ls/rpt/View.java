package pt.isel.deetc.ls.rpt;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public abstract class View {
	protected PrintStream _ps=null;

	public View(String fileName) throws FileNotFoundException{
		if(fileName==null || fileName.length()==0)
			_ps = System.out;
		else
			_ps = new PrintStream(new FileOutputStream(fileName));
	}
	
	public void printDoc(Map<String,List<List<String>>> rpt){
		Iterator<Map.Entry<String, List<List<String>>>> it = rpt.entrySet().iterator();
		openDoc(); // Document overture
		Map.Entry<String, List<List<String>>> table;
		while(it.hasNext()){
			table = it.next();
			printTitle(table.getKey());
			printTable(table.getValue());
		}
		closeDoc(); // Document closure
	}
	
	public void printDoc(List<List<String>> hdr){
		openDoc(); // Document overture
		printTable(hdr);
		closeDoc(); // Document closure
	}
	
	private void printTable(List<List<String>> hdr){
		openTable();
		boolean first = true;
		for(List<String> row: hdr){
			if(first){
				printHeader(row);
				first=false;
			}
			else
				printRow(row);
		}
		closeTable();
	}
	
	protected void printRow(List<String> row){
		openRow();
		for(String r:row)
			printElem(r);
		closeRow();
	}
	
	protected void printHeader(List<String> hdr){
		printRow(hdr);
	};

	/* Document */
	protected void openDoc() {}		// Document overture terms
	protected void closeDoc() {}	// Document closure terms
	
	/* Table */
	protected void openTable(){}	// Table overture terms
	protected void closeTable(){} 	// Table closure terms

	protected abstract void openRow();		// Table row overture terms
	protected abstract void closeRow();		// Table row closure terms
	
	protected abstract void printTitle(String str); // Prints the Title
	protected abstract void printElem(String s);	// Prints an Element/Field
}
