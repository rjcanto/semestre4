package pt.isel.deetc.ls.rpt;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.common.Utils;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;


public abstract class Report extends Command{
	
	protected Connection _conn;
	private boolean _html=false;
	private String _fileName=null;
		
	public Report(String name, String description, SQLServerDataSource dts) {
		super(name, description, dts);
		getParameters().add(new CommandParameter("view",true,"(html|plain)",false){
			public String getValue() { return _html?"html":"plain"; }
			public boolean setValue(String p) { _html=p.compareToIgnoreCase("html")==0; 
			return true;}
		});
		getParameters().add(new CommandParameter("output",true,"<filename>",false){
			public String getValue() { return _fileName; }
			public boolean setValue(String p) { _fileName=p;return true; }
		});
	}
	public void clear(){
		_html=false;
		_fileName=null;
	}
	protected final void runRepOneTable() throws SQLException, FileNotFoundException{
		_conn= getDts().getConnection() ;
		try {
			getViewer().printDoc(getData());
		}
		finally{
		    _conn.close();
		}
	}

	protected List<List<String>> getData() throws SQLException{
		return getData(getSelectString());
	}
	
	//protected void runRepTwoTable(String reportStmt, View view) throws SQLException, FileNotFoundException;
	protected List<List<String>> getData(String statement) throws SQLException{
		PreparedStatement stmt=_conn.prepareStatement(statement);
		
		ResultSet rs = stmt.executeQuery();
		
		List<List<String>> table = new LinkedList<List<String>>();
		List<String>hdr=Utils.getHeader(rs);
		int [] colsz= new int[hdr.size()];
		table.add(hdr);
		int colCount=rs.getMetaData().getColumnCount();
		while(rs.next()) {
			List<String> row = new ArrayList<String>(colCount);
			for(int i=1; i<= colCount;i++){
				colsz[i-1]=rs.getMetaData().getColumnDisplaySize(i);
				row.add(Utils.format(rs.getString(i),colsz[i-1]));
			}
			table.add(row);
		}
		return table;
	}	
	
	protected View getViewer() throws FileNotFoundException {
		if(_html)
			return new PackHtml(_fileName);
		return new PackText(_fileName);
	}

	
	protected abstract String getSelectString();

	public void run() throws SQLException,FileNotFoundException {
		runRepOneTable();
		clear();
	}
}


		

