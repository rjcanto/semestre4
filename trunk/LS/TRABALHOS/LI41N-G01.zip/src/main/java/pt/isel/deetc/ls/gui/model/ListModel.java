package pt.isel.deetc.ls.gui.model;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import javax.swing.AbstractListModel;


public class ListModel<E> extends AbstractListModel implements List<E>{

	private static final long serialVersionUID = 1L;
	private List<E> elems ;
	
	public ListModel(List<E> l){
		super();
		elems=l;
	}

	public ListModel(){
		super();
		elems= new LinkedList<E>();;
	}
	@Override
	public boolean add(E e) {
		elems.add(e);
		fireIntervalAdded(this, elems.size()-1, elems.size()-1);
		return true;
	}
	@Override
	public void add(int index, E element) {
		elems.add(index, element);
		fireIntervalAdded(this, index, index);
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		for (E e : c) {
			this.add(e);
		}
		fireContentsChanged(this, 0, elems.size());
		return true;
	}
	@Override
	public boolean addAll(int index, Collection<? extends E> c) {
		boolean result=elems.addAll(index, c);
		fireContentsChanged(this, index, elems.size()-1);
		return result;
	}

	@Override
	public void clear() {
		int size = elems.size();
		elems.clear();
		fireIntervalRemoved(this, 0, size-1);
	}

	@Override
	public boolean contains(Object o) {
		return elems.contains(o);
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return elems.containsAll(c);
	}

	@Override
	public E get(int index) {
		return elems.get(index);
	}

	@Override
	public int indexOf(Object o) {
		return elems.indexOf(o);
	}

	@Override
	public boolean isEmpty() {
		return elems.isEmpty();
	}

	@Override
	public Iterator<E> iterator() {
		return elems.iterator();
	}

	@Override
	public int lastIndexOf(Object o) {
		return elems.lastIndexOf(o);
	}

	@Override
	public ListIterator<E> listIterator() {
		return elems.listIterator();
	}

	@Override
	public ListIterator<E> listIterator(int index) {
		return elems.listIterator(index);
	}

	@Override
	public boolean remove(Object o) {
		int idx=elems.indexOf(o);
		if(idx==-1)
			return false;
		fireIntervalRemoved(this, idx, idx);
		return true;
	}

	@Override
	public E remove(int index) {
		E e = elems.remove(index);
		fireIntervalRemoved(this, index, index);
		return e;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		boolean result = elems.removeAll(c);
		if(result)
			fireContentsChanged(this, 0, elems.size()-1);
		return result;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		boolean r=elems.retainAll(c);
		fireContentsChanged(this, 0, elems.size()-1);
		return r;
	}

	@Override
	public E set(int index, E element) {
		E e=elems.set(index, element);
		fireContentsChanged(this, index, index);
		return e;
	}

	@Override
	public int size() {
		return elems.size();
	}

	@Override
	public List<E> subList(int fromIndex, int toIndex) {
		return elems.subList(fromIndex, toIndex);
	}

	@Override
	public Object[] toArray() {
		return elems.toArray();
	}
	@SuppressWarnings("unchecked")
	@Override
	public <T> T[] toArray(T[] a) {
		return  (T[]) elems.toArray();
	}

	@Override
	public Object getElementAt(int index) {
		return this.get(index);
	}

	@Override
	public int getSize() {
		return this.size();
	}
}

