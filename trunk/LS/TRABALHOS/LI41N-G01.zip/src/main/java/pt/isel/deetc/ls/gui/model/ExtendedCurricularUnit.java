package pt.isel.deetc.ls.gui.model;

import java.util.List;

import pt.isel.deetc.ls.model.ContactoUC;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Teacher;

public class ExtendedCurricularUnit {
	private CurricularUnit _uc;
	private String _elective;
	private List<ContactoUC> _lc;
	private int _semCurr;
	private List<Teacher> _lt;

	public ExtendedCurricularUnit(
			CurricularUnit uc,
			String elective, 
			int semCurr, 
			List<ContactoUC> lc,
			List<Teacher> lt){
		this(uc, elective, semCurr, lc);
		setListTeacher(lt);
	}
	public ExtendedCurricularUnit(
			CurricularUnit uc,
			String elective, 
			int semCurr, 
			List<ContactoUC> lc){
		_uc=uc;
		_elective=elective;
		_lc=lc;
		_semCurr=semCurr;
	}

	public CurricularUnit getUC(){
		return _uc;
	}
	public void setUC(CurricularUnit uc){
		_uc=uc;
	}
	public String getElective(){
		return _elective;
	}
	public void setElective(String e){
		_elective=e;
	}

	public String getName() {
		return _uc.getName();
	}

	public String getAcronym() {
		return _uc.getAcronym();
	}

	public double getCredits() {
		return _uc.getCredits();
	}

	public void setName(String n) {
		_uc.setName(n);
	}

	public void setAcronym(String a) {
		_uc.setAcronym(a);
	}

	public void setEcts(Double c) {
		_uc.setEcts(c);
	}
	@Override
	public String toString() {
		return "<html><body>"+ _semCurr +"  -  "+_uc.getName()+"</body>\n</html>\n";
	}

	@Override
	public boolean equals(Object obj) {
		return _uc.equals(obj);
	}

	@Override
	public int hashCode(){
		return _uc.hashCode();
	}

	public void setContactList(List<ContactoUC> lc) {
		_lc = lc;
	}

	public List<ContactoUC> getContactList() {
		return _lc;
	}

	public void setSemCurr(int _semCurr) {
		this._semCurr = _semCurr;
	}

	public int getSemCurr() {
		return _semCurr;
	}
	public void setListTeacher(List<Teacher> _lt) {
		this._lt = _lt;
	}
	public List<Teacher> getListTeacher() {
		return _lt;
	}

}
