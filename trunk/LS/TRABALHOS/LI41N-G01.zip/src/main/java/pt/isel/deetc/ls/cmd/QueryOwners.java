package pt.isel.deetc.ls.cmd;

import java.io.FileNotFoundException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import pt.isel.deetc.ls.rpt.Report;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class QueryOwners extends Report {
	private String _course=null;
	
	public QueryOwners(SQLServerDataSource dts) {
		super("qowners","Shows the teachers and the curricular units that each one is responsible for.",dts);
		getParameters().add(new CommandParameter("course",true,"<course_acronym>",false){
			public String getValue() { return _course; }
			public boolean setValue(String p) { _course=p; return true;}
		});
	}
	@Override
	public void clear() {_course=null;}
	public void run() throws SQLException,FileNotFoundException {
		runRepTwoTable();
	}

	protected void runRepTwoTable() throws SQLException, FileNotFoundException{
		_conn= getDts().getConnection() ;
		String aux=_course.matches("([a-z]|[A-Z]|[0-9])*")? " H.acrCurso = '"+_course+"' and" : "AND FALSE";
		aux = _course.length()==0? "": aux;
		String defaultStmt ="SELECT	  uc.nome as Nome," +
										" uc.acronimo as Acr�nimo," +
										" uc.creditos as Cr�ditos" +
							" FROM UC RIGHT JOIN HIST_PROF_UC as PUC " +
								" ON (uc.acronimo = PUC.acrUC) " +
							" WHERE PUC.anoLectFim is NULL " +
							" AND UC.acronimo in " +
								" (select acrUC from HIST_CURSO_UC as H " +
								"  where "+ aux +" H.anoLectFim is null) AND PUC.numDocente = ";

		String docName ="select nome as Nome from DOCENTE where numero = ";
		try {
			Map<String,List<List<String>>> quc = new LinkedHashMap<String, List<List<String>>>();
			PreparedStatement stmt=_conn.prepareStatement(getSelectString());
			ResultSet rs = stmt.executeQuery();
			while(rs.next()){
				stmt=_conn.prepareStatement(docName + rs.getString(1));
				ResultSet rsDN = stmt.executeQuery(); rsDN.next();
				quc.put(rsDN.getString(1), getData(defaultStmt+rs.getString(1)) );
			}
			getViewer().printDoc(quc);
		}
		finally{
		    _conn.close();
		}
	}

	@Override
	protected String getSelectString() {
		String aux=_course.matches("([a-z]|[A-Z]|[0-9])*")? " and uc.acrUC in (select acrUC from HIST_CURSO_UC as H where H.acrCurso = '"+_course+"' and H.anoLectFim is null)" : "AND FALSE";
		aux = _course.length()==0? "": aux;
		return "SELECT dc.numero as num from docente as dc inner join HIST_PROF_UC as uc on (dc.numero = uc.numDocente) "+ aux+" group by dc.numero order by COUNT(*) desc";

	}



	
}
