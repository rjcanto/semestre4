package pt.isel.deetc.ls.rpt;

import java.io.FileNotFoundException;
import java.util.List;



public class PackHtml extends View{

	public PackHtml(String fileName) throws FileNotFoundException {
		super(fileName);
	}

	protected void openDoc(){
		_ps.print("<html>\n<body>\n");
	};  // Document overture terms
	
	protected void closeDoc(){
		_ps.print("</body>\n</html>\n");
	}; // Document closure terms
	
	protected void openTable(){
		_ps.print("<table border=\"1\">\n");
	}; // Table overture terms

	protected void closeTable(){
		_ps.print("\n</table>\n");
	} // Table closure terms

	protected void openRow(){
		_ps.print("\n<tr>\n");
	}; // Table row overture terms
	
	protected void closeRow(){
		_ps.print("\n</tr>\n");
	}; // Table row closure terms
	
	protected void printTitle(String str){
		_ps.print("<h2>"+str+"</h2>");
	};
	
	@Override
	protected void printHeader(List<String> hdr){
		openRow();
		for(String hr:hdr)
			_ps.print("<th>"+hr+"</th>");
		closeRow();
	};

	protected void printElem(String s) {
		_ps.print("<td>"+s.trim()+"</td>");
	};
}


