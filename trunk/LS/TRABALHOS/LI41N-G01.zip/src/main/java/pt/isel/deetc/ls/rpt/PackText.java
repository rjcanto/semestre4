package pt.isel.deetc.ls.rpt;

import java.io.FileNotFoundException;
import java.util.List;

import pt.isel.deetc.ls.common.Utils;


public class PackText extends View {

	private final char COLUMN_DELIMITER =' ';

	public PackText(String fileName) throws FileNotFoundException {
		super(fileName);
	}
	
	protected void closeTable(){
		_ps.print("\n");
	} // Table closure terms

	protected void openRow(){
		_ps.print("\t");
	}; // Table row overture terms
	
	protected void closeRow(){
		_ps.print("\n");
	}; // Table row closure terms
	
	protected void printTitle(String str){
		_ps.print(str+'\n');
	};
	
	@Override
	protected void printHeader(List<String> hdr){
		openRow();
		int size=0;
		for(String hr:hdr){
			_ps.print(hr);
			// If col. delimiter is a String, change the 1 to str.length()
			size+=hr.length()+1; 
		}
		closeRow();
		_ps.print("\t"+Utils.repeat(size,'-'));
		closeRow();
	};

	protected void printElem(String s) {
		_ps.print(s+COLUMN_DELIMITER);
	};

}
