/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 

package pt.isel.deetc.ls.cmd;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import pt.isel.deetc.ls.common.Utils;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class RemoveOwner extends Command {
	
	private String _nm=null;
	
	public RemoveOwner(SQLServerDataSource dts) {
		super("rdoc", "Removes an owner from the Database", dts);
		getParameters().add(new CommandParameter("nm",true,"<teatcher_id>",false){
			public String getValue() { return _nm; }
			public boolean setValue(String p) { _nm=p; return true;}
		});
	}

	public void run() throws SQLException{
		// TODO - This command must re redesigned or removed, because it uses the old data model.
		Connection con=null;
		try {
			con = getDts().getConnection() ;
			String cmdDelete = "DELETE FROM DOCENTE WHERE DOCENTE.numero = ?" ;
			PreparedStatement statement = con.prepareStatement(cmdDelete) ;
			statement.setInt(1, Integer.valueOf(_nm).intValue()) ;
			statement.executeUpdate(); 
		}
		catch (SQLException e ){
			Utils.writeUserError("Database fault", "Teatcher could not be eliminated.");
		}
		finally{
			if(con!=null) con.close();
		}
		System.out.println("Teacher was successfuly removed") ;
	}

	@Override
	public void clear() { _nm=null; }

}
