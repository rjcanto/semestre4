package pt.isel.deetc.ls.mapper;

import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.model.*;
import pt.isel.deetc.ls.mapper.Mapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class CurricularUnitMapper extends Mapper<CurricularUnit> {
	public CurricularUnitMapper(Connection _c){
		super(_c);
	}

	public int delete(CurricularUnit uc) throws SQLException {
		PreparedStatement statement=null;
		int nDeleted=0;
		try{
			String cmdDelete = "DELETE FROM UC WHERE UC.acronimo = ?" ;
			statement = _c.prepareStatement(cmdDelete) ;
			statement.setString(1, uc.getAcronym()) ;
			nDeleted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nDeleted;
	}

	public int delete(CurricularUnit uc, Course c, Semester s) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("UPDATE HIST_CURSO_UC SET"+
					" HIST_CURSO_UC.anoLectFim=?, HIST_CURSO_UC.semLectFim=? "+
			"WHERE HIST_CURSO_UC.acrUC=? AND HIST_CURSO_UC.acrCurso=?") ;
			statement.setString(1, s.getYear()) ;
			statement.setString(2, s.getSeason()) ;
			statement.setString(3, uc.getAcronym()) ;
			statement.setString(4, c.getAcr()) ;
			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	public int deleteTeacherInUc(CurricularUnit uc, Teacher t, Semester s) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("UPDATE HIST_DOC_UC SET "+
					"HIST_DOC_UC.anoLectFim=?, HIST_DOC_UC.semLectFim=? "+
					"WHERE HIST_DOC_UC.numDocente=? AND HIST_DOC_UC.acrUC=? " +
			"AND HIST_DOC_UC.anoLectFim IS NULL") ;
			statement.setString(1, s.getYear()) ;
			statement.setString(2, s.getSeason()) ;
			statement.setInt(3, t.getNBRMEC()) ;
			statement.setString(4, uc.getAcronym()) ;
			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	@Override
	public int insert(CurricularUnit uc) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("INSERT INTO UC "+
			"(acronimo, nome, creditos) values (?,?,?)") ;
			statement.setString(1, uc.getAcronym()) ;
			statement.setString(2, uc.getName()) ;
			statement.setDouble(3, uc.getCredits()) ;
			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	public int insert(CurricularUnit uc, Course c, Semester s, 
			int semCurricular, String caracter) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("INSERT INTO HIST_CURSO_UC "+
					"(acrCurso,acrUC,anoLectIni,semLectIni, anoLectFim, " +
			"semLectFim, semCurricular, caracter) values (?,?,?,?,?,?,?,?)") ;
			statement.setString(1, c.getAcr()) ;
			statement.setString(2, uc.getAcronym()) ;
			statement.setString(3, s.getYear()) ;
			statement.setString(4, s.getSeason()) ;
			statement.setString(5, null) ;
			statement.setString(6, null) ;
			statement.setInt(7, semCurricular) ;
			statement.setString(8, caracter) ;

			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}


	public int insertTeacherInUc(CurricularUnit uc, Teacher t, Semester s) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("INSERT INTO HIST_DOC_UC "+
					"(numDocente,anoLectIni,semLectIni, anoLectFim, " +
			"semLectFim, acrUC) values (?,?,?,?,?,?)") ;
			statement.setInt(1, t.getNBRMEC()) ;
			statement.setString(2, s.getYear()) ;
			statement.setString(3, s.getSeason()) ;
			statement.setString(4, null) ;
			statement.setString(5, null) ;
			statement.setString(6, uc.getAcronym()) ;

			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	@Override
	public int update(CurricularUnit uc) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		try{
			statement = _c.prepareStatement("UPDATE UC SET "+
					"UC.nome=?, UC.creditos=?"+
			" WHERE UC.acronimo=?") ;
			statement.setString(1, uc.getName()) ;
			statement.setDouble(2, uc.getCredits()) ;
			statement.setString(3, uc.getAcronym()) ;
			nUpdated=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}

	public int update(String acr, CurricularUnit uc) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		try{
			statement = _c.prepareStatement("UPDATE UC SET "+
					"UC.acronimo=?,"+
					"UC.nome=?, UC.creditos=? "+
			"WHERE UC.acronimo=?") ;
			statement.setString(1, uc.getAcronym()) ;
			statement.setString(2, uc.getName()) ;
			statement.setDouble(3, uc.getCredits()) ;
			statement.setString(4, acr ) ;

			nUpdated=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}

	public int updateEndSemester(CurricularUnit uc, Course c, 
			Semester sEnd) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("UPDATE HIST_CURSO_UC "+
					"SET anoLectFim=?, semLectFim=? " +
			"WHERE acrCurso=? AND acrUC=?;") ;
			statement.setString(1, sEnd.getYear()) ;
			statement.setString(2, sEnd.getSeason()) ;
			statement.setString(3, c.getAcr()) ;
			statement.setString(4, uc.getAcronym()) ;

			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	/**
	 * Updates a CurricularUnit in a specific course. It's possible to change a Curricular Semester and the
	 * type. The CurricularUnit must be already associated to the Course and sBegin should be between the 
	 * historical range of the CurricularUnit/Course association.
	 * 
	 * @param c 			The Course	
	 * @param uc			The CurricularUnit
	 * @param sBegin		The Semester in which the changes start to apply
	 * @param semCurricular The Curricular Semester that the Curricular Unit is in the Course
	 * @param type 			The type, if is 'obrigat�rio' or 'opcional'
	 * @return				The number of tuples changed
	 * @throws SQLException
	 * @throws BadParameterException
	 */
	public int updateUCCourse(Course c, CurricularUnit uc, Semester sBegin, 
			int semCurricular, String type) throws SQLException, BadParameterException {
		PreparedStatement statement=null;
		CourseMapper cMapper = new CourseMapper(_c) ;
		int nUpdated= 0;
		if (uc.validateType(type) && cMapper.findActiveUCinCourse(c,uc)) { // Aplica��o de restri��o
			try {
				Semester sEndOld = cMapper.selectUCEndSemester(c,uc) ;
				if(sEndOld == null || sBegin.compareBeginTo(sEndOld)<0) {
					updateEndSemester(uc, c, sBegin) ;
					nUpdated = insert(uc, c, sBegin, semCurricular, type) ;
				}
			}finally{
				if(statement!=null) statement.close();
			}
		}
		return nUpdated ;	
	}

	public int updateOwner(CurricularUnit uc, Teacher t, Semester s) throws SQLException {
		PreparedStatement statOld=null;
		PreparedStatement statNew=null;
		String strOld = "UPDATE HIST_PROF_UC SET "+
		"HIST_PROF_UC.anoLectFim=?, HIST_PROF_UC.semLectFim=? "+
		"WHERE HIST_PROF_UC.acrUC=?" ;
		String strNew = "INSERT INTO HIST_PROF_UC(" +
		"anoLectIni,semLectIni, anoLectFim, semLectFim," +
		"acrUC,numDocente) VALUES(?,?,?,?,?,?)" ;
		int nUpdated=0;
		try{
			_c.setAutoCommit(false);

			statOld = _c.prepareStatement(strOld) ;
			statOld.setString(1, s.getYear()) ;
			statOld.setString(2, s.getSeason()) ;
			statOld.setString(3, uc.getAcronym()) ;
			nUpdated=statOld.executeUpdate();

			statNew = _c.prepareStatement(strNew);
			statNew.setString(1, s.getYear()) ;
			statNew.setString(2, s.getSeason()) ;
			statNew.setString(3, null );
			statNew.setString(4, null );
			statNew.setString(5, uc.getAcronym());
			statNew.setInt(6,t.getNBRMEC()) ;
			nUpdated+=statNew.executeUpdate();

			_c.commit() ;
		}
		finally{
			if(statOld!=null) statOld.close();
		}
		return nUpdated;
	}

	@Override
	public boolean find(CurricularUnit t) throws SQLException {
		PreparedStatement statement=null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT UC.acronimo, UC.nome, UC.creditos "+ 
			"FROM UC WHERE UC.acronimo=?") ;
			statement.setString(1, t.getAcronym()) ;
			rs=statement.executeQuery();
			if(rs.next())
				return true;
			return false;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}

	public boolean findTeacherUCinSemester(CurricularUnit uc, Teacher t, Semester s) throws SQLException, BadParameterException {
		PreparedStatement statement=null;
		SemesterMapper sMapper = new SemesterMapper(_c) ;
		ResultSet rs;
		Semester tempSemBegin ;
		Semester tempSemEnd ;
		try{
			statement = _c.prepareStatement(
					"SELECT HIST_DOC_UC.anoLectIni, HIST_DOC_UC.semLectIni, " +
					"HIST_DOC_UC.anoLectFim, HIST_DOC_UC.semLectFim " + 
			"FROM HIST_DOC_UC WHERE HIST_DOC_UC.acrUC=? AND HIST_DOC_UC.numDocente=?") ;
			statement.setString(1, uc.getAcronym()) ;
			statement.setInt(2, t.getNBRMEC()) ;
			rs=statement.executeQuery();
			while(rs.next()) {
				tempSemBegin = sMapper.selectSem(rs.getString("anoLectIni"),rs.getString("semLectIni")) ;
				if (rs.getString("anoLectFim") == null) {
					tempSemEnd = null ;
					if (tempSemBegin.compareBeginTo(s)<=0) return true ;
				}	
				else {
					tempSemEnd = sMapper.selectSem(rs.getString("anoLectFim"),rs.getString("semLectFim")) ;
					if (tempSemBegin.compareBeginTo(s)<=0 && tempSemEnd.compareBeginTo(s) >= 0 )
						return true ;
				}
			}
			return false;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}

	@Override
	public List<CurricularUnit> select() throws SQLException {
		PreparedStatement statement=null;
		List<CurricularUnit> list = new LinkedList<CurricularUnit>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT UC.acronimo, UC.nome, UC.creditos"+
			" FROM UC") ;
			rs=statement.executeQuery();
			while(rs.next()) {
				list.add(new CurricularUnit(rs.getString("acronimo"),rs.getString("nome"),
						rs.getDouble("creditos"))) ;
			}
			return list;
		}finally{
			if(statement!=null) 
				statement.close();
		}
	}

	public CurricularUnit selectAcronimo(String acronimo) throws SQLException {
		PreparedStatement statement=null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT UC.acronimo, UC.nome, UC.creditos"+
			" FROM UC WHERE UC.acronimo=?") ;
			statement.setString(1, acronimo) ;
			rs=statement.executeQuery();
			while(rs.next())
				return(new CurricularUnit(rs.getString("acronimo"),rs.getString("nome"),
						rs.getDouble("creditos"))) ;
			return null;
		}finally{
			if(statement!=null) 
				statement.close();
		}
	}

	public Teacher selectCurrentOwnerFromUC(CurricularUnit uc) throws SQLException {
		PreparedStatement statement=null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT DOCENTE.numero, DOCENTE.nome, " +
					"DOCENTE.email, DOCENTE.tipo "+ 
					"FROM DOCENTE INNER JOIN HIST_PROF_UC ON " +
					"(DOCENTE.numero=HIST_PROF_UC.numDocente) " +
			"WHERE HIST_PROF_UC.acrUC=? AND HIST_PROF_UC.anoLectFim IS NULL") ;
			statement.setString(1, uc.getAcronym()) ;
			rs=statement.executeQuery();
			if(rs.next()) {
				return(new Teacher(
						rs.getInt("numero"),
						rs.getString("nome"),
						rs.getString("email"),
						rs.getString("tipo"))) ;
			}
			return null;
		}finally{
			if(statement!=null) 
				statement.close();
		}
	}

	public List<Teacher> select(CurricularUnit uc, Semester s) throws SQLException {
		PreparedStatement statement=null;
		List<Teacher> list = new LinkedList<Teacher>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement(
					"SELECT  DISTINCT d.nome, d.numero, d.tipo, d.email FROM  DOCENTE as d"+
					" INNER JOIN HIST_DOC_UC as h"+
					" ON (d.numero=h.numDocente)"+
					" WHERE h.acrUC=?"+
					" and (h.anoLectFim is null or h.anoLectFim >= ? )"+
					" and (h.semLectFim is null or h.semLectFim >= ?)"+
			" and (h.anoLectIni <= ?) and h.semLectIni <= ?");
			statement.setString(1, uc.getAcronym()) ;
			statement.setString(2, s.getYear()) ;
			statement.setString(3, s.getSeason()) ;
			statement.setString(4, s.getYear()) ;
			statement.setString(5, s.getSeason()) ;
			rs=statement.executeQuery();
			while(rs.next()) {
				list.add(new Teacher(rs.getInt("numero"),rs.getString("nome"),
						rs.getString("email"),rs.getString("tipo"))) ;
			}
			return list;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}

}
