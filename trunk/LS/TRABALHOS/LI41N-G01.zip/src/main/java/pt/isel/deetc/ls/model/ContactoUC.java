package pt.isel.deetc.ls.model;

public class ContactoUC {
	private double _horas;
	private String _tipo;
	private String _acronimo;
	
	public ContactoUC(double h,String t, String acronimo){
		this._horas=h;
		this._tipo=t;
		this._acronimo=acronimo;
	}
	
	public String getAcr() {
		return _acronimo;
	}
	
	public double getHours() {
		return _horas;
	}
	public String getType() {
		return _tipo;
	}
	
	@Override
	public String toString(){
		return _acronimo+":"+_tipo+":"+_horas;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) 
			return false;
		
		if(obj.getClass() != getClass()){
			return false;
		}
		
		ContactoUC ht = (ContactoUC) obj ;
		if (ht._tipo == this._tipo)
			return true ;
		return false ;
	}
	
	@Override
	public int hashCode(){
		return _tipo.hashCode();
	}

}