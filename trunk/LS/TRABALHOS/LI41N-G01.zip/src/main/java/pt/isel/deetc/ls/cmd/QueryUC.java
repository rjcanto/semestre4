package pt.isel.deetc.ls.cmd;

import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.rpt.Report;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class QueryUC extends Report {
	private String _param=null;
	private String _course=null;

	public QueryUC(SQLServerDataSource dts) {
		super("quc","Shows the Elective or Required Curricular Units", dts);
		getParameters().add(new CommandParameter("type",true,"(elective|required)",false){
			public String getValue() { return _param; }
			public boolean setValue(String p) { 
				if(p.compareToIgnoreCase("required")==0)
					{_param="obrigat�rio"; return true;} 
				if(p.compareToIgnoreCase("elective")==0)
					{_param="opcional"; return true;} 
				Utils.feedBack("invalid value for parameter -"+this.getName());
				Utils.feedBack(usage());
				return false;
			}
		});
		getParameters().add(new CommandParameter("course",true,"<course>",false){
			public String getValue() { return _course; }
			public boolean setValue(String p) { 
				_course=p;
				return p!=null;
			}
		});
	}

	protected String getSelectString() {
		String aux=_course.matches("([a-z]|[A-Z]|[0-9])*")? " AND HCU.acrCurso = '"+_course+"'" : "AND FALSE";
		aux = _course.length()==0? "": aux;
		return "SELECT HCU.acrUC as Acronimo, HCU.caracter as Tipo, HCU.acrCurso as Curso" +
				" from HIST_CURSO_UC as HCU " +
				" where HCU.anoLectFim is null " +
				" AND HCU.caracter = '"+_param+"'" + aux;
	}

	@Override
	public void clear() {_param=null; _course=null; super.clear();}
}
