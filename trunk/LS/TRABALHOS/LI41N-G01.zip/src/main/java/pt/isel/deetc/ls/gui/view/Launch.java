package pt.isel.deetc.ls.gui.view;

import java.awt.BorderLayout;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.SwingUtilities;

public class Launch {
	static JDialog dialog;
	public static JDialog lauchDialog(
			final JComponent cmp, final boolean modal, final String title, boolean wait) throws InterruptedException, InvocationTargetException{
		
		Runnable r = new Runnable(){
			public void run(){
				dialog = new JDialog();
				dialog.add(cmp, BorderLayout.CENTER);
				dialog.setModal(modal);
				dialog.setTitle(title);
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.pack();
				dialog.setVisible(true);
			}
		};
		if(!wait)
			SwingUtilities.invokeLater(r);
		else
			SwingUtilities.invokeAndWait(r);
		return dialog;
	}

}
