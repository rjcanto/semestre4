package pt.isel.deetc.ls.cmd;



import pt.isel.deetc.ls.rpt.Report;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class QueryUC_Owners extends Report {
	private String _course=null;
	private String _nm = null;

	public QueryUC_Owners(SQLServerDataSource dts) {
		super("quc_owner","Shows the CUs who's responsible is given as parameter.",dts);
		getParameters().add(new CommandParameter("course",true,"<course_acronym>",false){
			public String getValue() { return _course; }
			public boolean setValue(String p) { _course=p; return true;}
		});
		getParameters().add(new CommandParameter("owner",true,"<owner_number>",false){
			public String getValue() { return _nm; }
			public boolean setValue(String p) { _nm=p; return true;}
		});
	}

	@Override
	protected String getSelectString() {
		String aux=_course.matches("([a-z]|[A-Z]|[0-9])*")? " AND HCU.acrCurso = '"+_course+"'" : "AND FALSE";
		aux = _course.length()==0? "": aux;
		return 	"SELECT distinct D.nome AS 'Nome', D.numero AS 'N�', HCU.acrCurso AS 'Curso', HPU.acrUC as 'UC'"+
				" FROM Docente AS D INNER JOIN hist_prof_uc HPU ON (HPU.numDocente=D.numero)" +
				" INNER JOIN HIST_CURSO_UC AS HCU ON (HPU.acrUC = HCU.acrUC)" +
				" WHERE HPU.anoLectFim IS NULL " + aux + " order by d.nome";
	}

	@Override
	public void clear() { _course=_nm=null;}
}
