package pt.isel.deetc.ls.cmd.etapa2;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.mapper.Mapper;
import pt.isel.deetc.ls.model.Course;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class CreateCourse extends Command {
	private String _acr;
	private String _name;

	public CreateCourse(SQLServerDataSource dts) {
		super("new", "Create a new Course", dts);
		clear();
		getParameters().add(new CommandParameter("acr",true,"<acronym>",false){
			public String getValue() { return ""; }
			public boolean setValue(String p) { _acr=p; return true; }
		});
		getParameters().add(new CommandParameter("name",true,"<course_name>",false){
			public String getValue() { return ""; }
			public boolean setValue(String p) { _name=p; return true; }
		});
	}

	public void setAcronym(String acr) { _acr=acr; }
	public void setName(String name) { _name=name; }
	
	@Override
	public void clear() {
		_acr=null;
		_name=null;
	}

	@Override
	public void run() throws SQLException, FileNotFoundException {
		Connection con = getDts().getConnection();
		Mapper<Course> m= new CourseMapper(con);
		m.insert(new Course(_acr, _name));
		con.close();
		clear();
	}

}
