package pt.isel.deetc.ls.common;


public class ApplicationExitException extends RuntimeException {
	
	//Generated automatically by Eclipse
	private static final long serialVersionUID = -735771922770251096L;

	public ApplicationExitException(){
		System.out.println("Bye.");
	}
}