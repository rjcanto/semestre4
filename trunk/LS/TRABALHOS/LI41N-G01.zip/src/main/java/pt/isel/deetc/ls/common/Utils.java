package pt.isel.deetc.ls.common;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

public class Utils {
	public static final Locale ptLocale=new Locale("pt","PT");
	public static boolean isValidEmail(String email){
		return false;
	}
	public static DecimalFormat ptRegSetings(){
		DecimalFormatSymbols ptDecimalFormatSymbols=new DecimalFormatSymbols(ptLocale);
		ptDecimalFormatSymbols.setDecimalSeparator(',');
		ptDecimalFormatSymbols.setGroupingSeparator('.');
		return new DecimalFormat("#.##0,###",ptDecimalFormatSymbols);
	}
	
	public static void writeUserError(String errorType, String errorDescr) {
		System.err.printf("\nError: %s.\n%s\n", errorType, errorDescr);	
	}

	public static List<String> getHeader(ResultSet rs) throws SQLException{
	    ResultSetMetaData md = rs.getMetaData();
		List<String> quc = new LinkedList<String>();
	    int colCount = md.getColumnCount();
	    for(int i=1; i<=colCount; i++){
	    	String cn = md.getColumnName(i);
	    	quc.add(format(cn,md.getColumnDisplaySize(i)+1));
	    }
		return quc;
	}
		
	public static String format(String cn, int i) {
		return cn+repeat(i-cn.length(),' ');
	}
	public static String repeat(int i,char c){
		StringBuffer sb = new StringBuffer(100);
		for(;i>0;i--)
			sb = sb.append(c);
		return sb.toString();
	}
	public static void feedBack() {
		feedBack("Command executed successfuly.");	
	}
	public static void feedBack(String msg) {
		System.out.println(msg);	
	}
}
