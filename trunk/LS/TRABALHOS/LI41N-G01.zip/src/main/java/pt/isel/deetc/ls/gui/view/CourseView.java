package pt.isel.deetc.ls.gui.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.lang.reflect.InvocationTargetException;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import pt.isel.deetc.ls.gui.model.ExtendedCurricularUnit;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

public class CourseView extends JPanel{

	CurricularUnit _uc;
	JList ucList;
	private static final long serialVersionUID = 1L;
	JPopupMenu _popup;
	int curIndex;
	Semester _s;
	
	public CourseView(final SQLServerDataSource dts, final Course course, final Semester s, Teacher t, ListModel model){
		_s=s;
		setLayout(new BorderLayout());
		JTextField tfName, tfSeason, tfYear, tfOwnerName, tfOwnerEmail;
		
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(5,2));
		this.setLayout(new BorderLayout());

		// Name field
		JLabel lName = new JLabel("Name:");
//		lName.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lName);
		tfName = new JTextField( course.getNome() );
		tfName.setEditable(false);
		jp.add(tfName);
		
		// Semester Season
		JLabel lSeason = new JLabel("Season:");
//		lSeason.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lSeason);
		tfSeason = new JTextField( s.getSeason() );
		tfSeason.setEditable(false);
		jp.add(tfSeason);
	

		// Semester Year
		JLabel lYear = new JLabel("Year:");
//		lYear.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lYear);
		tfYear = new JTextField( s.getYear() );
		tfYear.setEditable(false);
		jp.add(tfYear);
		
		
		// Owner Name
		JLabel lOwnerName = new JLabel("Owner Name:");
//		lOwnerName.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lOwnerName);
		tfOwnerName = new JTextField( t.getNOME());
		tfOwnerName.setEditable(false);
		jp.add(tfOwnerName);

		// Owner Email
		JLabel lOwnerEmail = new JLabel("Owner Email:");
//		lOwnerEmail.setHorizontalAlignment(SwingConstants.RIGHT);
		jp.add(lOwnerEmail);
		tfOwnerEmail = new JTextField( t.getEMAIL() );
		tfOwnerEmail.setEditable(false);
		jp.add(tfOwnerEmail);
		
		add(jp,BorderLayout.NORTH);
		
		ucList = new JList(model);
		JScrollPane pane = new JScrollPane(ucList);
		pane.setBorder(new TitledBorder("Curricular Units:"));
		add(pane, BorderLayout.CENTER);
		
		_popup = new JPopupMenu();
		_popup.add(new AbstractAction("Edit"){
			private static final long serialVersionUID = 1L;
			public void actionPerformed(ActionEvent e) {
				try {
					Launch.lauchDialog(new UCEditor(dts, ucList, course, s), true, "Update Curricular Unit", false);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				} catch (InvocationTargetException e1) {
					e1.printStackTrace();
				}
			}
		});
		_popup.add(new AbstractAction("View"){
			private static final long serialVersionUID = 1L;
			public void actionPerformed(ActionEvent e) {
				viewUC();
			}
		});
		ucList.setComponentPopupMenu(_popup);
		ucList.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount() == 2)
					viewUC();
			}
		});
		ucList.setCellRenderer(new UCCellRenderer());
	}

	private void viewUC() {
		int idx=ucList.getSelectedIndex();
		if(idx<0)
			return;
		ExtendedCurricularUnit uc = (ExtendedCurricularUnit) ucList.getModel().getElementAt(idx);
		JDialog dialog = new JDialog();
		dialog.add(new UCViewer(uc), BorderLayout.CENTER);
		dialog.setModal(true);
		dialog.setTitle("View Curricular Unit");
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.pack();
		dialog.setVisible(true);
		dialog.setAlwaysOnTop(true);
	}


	public static void launchDialog(
			final JComponent cmp, final boolean modal, final String title) throws InterruptedException, InvocationTargetException{
		SwingUtilities.invokeAndWait( new Runnable(){
			public void run(){
				JDialog dialog = new JDialog();
				dialog.add(cmp, BorderLayout.CENTER);
				dialog.setModal(modal);
				dialog.setTitle(title);
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.pack();
				dialog.setVisible(true);
				dialog.setAlwaysOnTop(true);
			}
		});
	}

	public class UCCellRenderer extends JLabel implements ListCellRenderer{

		private static final long serialVersionUID = 1L;
		public UCCellRenderer() {
			setOpaque(true);
		}

		@Override

		public Component getListCellRendererComponent(
				JList list,
				Object value,
				int index,
				boolean isSelected,
				boolean cellHasFocus)
		{
			ExtendedCurricularUnit uc= (ExtendedCurricularUnit) value;
			setText(uc.toString());
			if(uc.getElective().compareToIgnoreCase("opcional")==0)
				setBackground(isSelected ? Color.blue : new Color(0xFFFFCC));
			else
				setBackground(isSelected ? Color.blue : new Color(0xFFFFFF));
			setForeground(isSelected ? Color.white : Color.black);
			return this;
		}
	}

}
