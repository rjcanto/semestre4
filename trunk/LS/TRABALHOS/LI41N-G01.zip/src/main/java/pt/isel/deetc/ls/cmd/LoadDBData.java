package pt.isel.deetc.ls.cmd;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.ListIterator;

import pt.isel.deetc.ls.common.FileParser;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.mapper.ContactoUCMapper;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.ContactoUC;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Teacher;


import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public class LoadDBData extends Command {
	Connection _con;
	private String _fileName=null;
	
	public LoadDBData(SQLServerDataSource dts) {
		super("load","Populates database tables",dts);
		getParameters().add(new CommandParameter("input",true,"<input_file_path>",false){
			public String getValue() { return _fileName; }
			public boolean setValue(String p) { _fileName=p; return true; }
		});
	}
	
	@Override
	public void clear(){
		_fileName=null;
	}  
	
	public void connect() throws SQLServerException{
		_con=getDts().getConnection();
	}
	public void disconnect() throws SQLException{
		_con.close();
	}
	
//	public void run() throws SQLException, IOException{
//		
//		try{
//			connect();
//			runSQLFile("_PopulateTables.sql");
//		}
//		catch(SQLException e){
//			Utils.writeUserError("Database fault", e.getMessage());
//
//		}
//		finally{
//			disconnect();			
//		}
//
//	}
	public void run() throws SQLException, IOException{
	
	try{
		connect();
		System.out.println("A ler ficheiro...");
		FileParser fparser = new FileParser(_fileName) ;
		System.out.println("Carregando as Unidades Curriculares...");
		LinkedList<CurricularUnit> listUC =fparser.getUnidadesCurriculares();
		System.out.println("Carregando os Docentes...");
		LinkedList<Teacher> listDocente=fparser.getDocentes();
		System.out.println("Carregando a rela��o UC - Contactos...");
		LinkedList<ContactoUC> listContactoUc=fparser.getContactoUc();

		System.out.println("Preenchendo a tabela Docente...");
		this.populateTeacher(listDocente) ;
		System.out.println("Preenchendo a tabela Unid_Curricular...");
		this.populateUC(listUC) ;
		System.out.println("Preenchendo a tabela ContactoUC...");
		this.populateContactoUc(listContactoUc) ;
		System.out.println("Comando terminado com sucesso!\n");
	}
	catch(SQLException e){
		Utils.writeUserError("Database fault", e.getMessage());

	}
	finally{
		disconnect();			
	}

}
//	private void DDLExec(String sqlStat) throws SQLException {
//		Statement stmt = _con.createStatement();
//		stmt.executeUpdate(sqlStat);
//		stmt.close();
//	}
	
	/*
	 * The SQL file that supports this method, shall include a ";" string after each 
	 * DDL command, otherwise, the statement that does not finishes with a ";" will not
	 * be execute, and can generate a SQL error.
	 */
//	private void runSQLFile(String str) throws SQLException, IOException {
//		BufferedReader in = null;
//		InputStream is = ClassLoader.getSystemResourceAsStream(str);
//		if(is==null){
//			System.err.println("Error on opening or reading "+str+" file.");
//			return;
//		}
//		in =  new BufferedReader(new InputStreamReader(is));
//		String line;
//		StringBuffer sb=new StringBuffer();
//		while((line=in.readLine())!=null){
//			sb.append(line+" ");
//			if(line.contains(";")){
//				DDLExec(sb.toString());
//				sb=new StringBuffer();
//			}
//		}
//	}
	
	public void populateTeacher(LinkedList<Teacher> docentes) throws SQLException {
		TeacherMapper tMapper = new TeacherMapper(_con) ;
		ListIterator<Teacher> lst=docentes.listIterator();
		while(lst.hasNext())
			tMapper.insert(lst.next());			
	}
	
	public void populateUC(LinkedList<CurricularUnit> uniCurriculares) throws SQLException{
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_con) ;
		ListIterator<CurricularUnit> lst=uniCurriculares.listIterator();
		while(lst.hasNext())
			ucMapper.insert(lst.next()) ;
	}
	
	private void populateContactoUc(LinkedList<ContactoUC> listContactosUc) throws SQLException {
		ContactoUCMapper cucMapper = new ContactoUCMapper(_con) ;
		ListIterator<ContactoUC> itListContactosUc = listContactosUc.listIterator();
		while(itListContactosUc.hasNext())
			cucMapper.insert(itListContactosUc.next()) ;
	}
	
}
