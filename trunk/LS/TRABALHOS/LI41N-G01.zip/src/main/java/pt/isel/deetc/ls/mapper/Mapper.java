package pt.isel.deetc.ls.mapper;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public abstract class Mapper<T> {
	Connection _c;

	public Mapper(Connection c){
		_c=c;
	}
	public Connection getConnection(){
		return _c;
	}
	public abstract int insert(T t) throws SQLException;
	public abstract int update(T t) throws SQLException;
	public abstract int delete(T t) throws SQLException;
	public abstract List<T> select() throws SQLException; //retorna todas as entradas da tabela
	public abstract boolean find(T t) throws SQLException;
}
