/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 31401 : Nuno Cancelo
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 
/*
 * Following functionalities are implemented using a SQLSErver specific strategy:
 * 	- Alternated Keys
 * 	- Domain constraints like: ck_DOCENTE_NUMERO CHECK ( numero > 0 ))
 * 
 * This kind of constraints are only available through the query of system tables,
 * and these tables are not standard across platforms. 
 * We did opt to develop only this functionalities through the existent views on 
 * INFORMATION_SCHEMA schema and all other meta-data gotten through the JDBC getMetaData
 * method in favor of the module's portability.  
 */
package pt.isel.deetc.ls.cmd;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;



import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

/* 
 * Objective: "Gerar script com instru��es SQL DDL (Data Definition Language) necess�rias
 * para recriar a base de dados."
 * Command: "etapa0 -gen_ddl <output_file_path>"
*/

public class GenerateDBSchema extends Command{

	// Instance fields
	private String _fileName=null;
	
	public GenerateDBSchema(SQLServerDataSource dts){
		super("gen_ddl","Produces DDL file for database creation",dts);
		getParameters().add(new CommandParameter("output",true,"<output_file_path>",false){
			public String getValue() { return _fileName; }
			public boolean setValue(String p) { _fileName=p; return true; }
		});
	}

	public void run() throws SQLException{
		
		PrintStream ps  = null;
		Connection con  = null;
		ResultSet rsTn = null, rsEx = null, rsSc = null, rsPk=null, rsFk = null;
		DatabaseMetaData dbmd = null;
		
		try{
			
			// Open the Output File that will have the SQL statements
			ps = new PrintStream(new FileOutputStream(_fileName));
			
			// Get connected with DB
			con=getDts().getConnection();
			// Get MetaData about DB
			dbmd = con.getMetaData();
			// *******method getDatabaseName doesn't work properly.*******
			ps.printf("USE LS2;\n\n");// ,getDts().getDatabaseName()); 
			// ps.printf("USE %s;\n\nBEGIN TRANSACTION\n\n",sqlserver.getDatabaseName());
			
			/************* Get Schemas (one by one) ***************/
			String[] types = {"TABLE"};
			rsSc = dbmd.getSchemas();
			while(rsSc.next()){ // Foreach schema, get tables ...
				String SchemaName = rsSc.getString(1);
				rsTn = dbmd.getTables(null, SchemaName, "%", types);

				while (rsTn.next()){ // Foreach tables, get columns ...
					String tn = rsTn.getString("TABLE_NAME");
					rsEx = QueryExec(con, "Select top 1 * from "+tn);

					ps.printf("CREATE TABLE %s.%s(\n",SchemaName, tn);
					
					ResultSetMetaData rsmd = rsEx.getMetaData();
					String sep="";
					
					/*
					 * Foreach column, get other attributes...
					 */
					for (int i = 1; i <= rsmd.getColumnCount(); i++){
						// Obtain Column Name
						String colName = rsmd.getColumnName(i);
						// Obtain Column Type
						String colType = rsmd.getColumnTypeName(i); 
						// Obtain Column Precision
						int precision = rsmd.getPrecision(i);
						// Obtain Column Scale					
						int Scale = rsmd.getScale(i);
						// Column allows null?
						int colIsNullable = rsmd.isNullable(i);
						
						// Write columns data on output file...
						ps.printf("%s\t%s %s" ,sep, colName, colType);
						// bit, int and real does not 
						if(!colType.toLowerCase().matches("bit|int|real"))
							if(precision< 0xFFFF){
								ps.printf("(%d", precision);
								if(Scale>0)
									ps.printf(",%d",Scale);
								ps.printf(")");
							}
						ps.printf("%s NULL", colIsNullable==ResultSetMetaData.columnNoNulls ? " NOT" : "");
						sep=",\n";
					}
					
					/********** Get Primary Keys *************/
					rsPk = dbmd.getPrimaryKeys(null, SchemaName, tn);
					if(rsPk.next()){
						ps.print(sep + "\tCONSTRAINT "+rsPk.getString("PK_NAME")+" PRIMARY KEY ( "+rsPk.getString("COLUMN_NAME") );
						
						while(rsPk.next())
							ps.printf(", %s ", rsPk.getString("COLUMN_NAME"));

						ps.print(" )");
					}
					ps.printf("\n);\n"); // Closes the table parenthesis 
				}
				rsTn.close();
			}
			rsSc.close();

			rsSc = dbmd.getSchemas();
			ps.println("\n/* Foreign Keys Constraints */");
			while(rsSc.next()){ // Foreach schema, get tables ...
				String SchemaName = rsSc.getString(1);

				rsTn = dbmd.getTables(null, SchemaName, "%", types);
				while (rsTn.next()){ // Foreach tables, get ForeignKeys ...
					String tn = rsTn.getString("TABLE_NAME");
					/********** Get Foreign Keys *************/
					printForeignKeys(ps, dbmd, SchemaName, tn);
				}
				rsTn.close();
			}
			rsSc.close();
			/********** Get column Constraint **********/
			printConstraintsSQL(ps, con, dbmd);
			/********** Get Alternate Keys *************/
			printAlternateKeysSQL(ps, con, dbmd);
//			ps.printf("\n\nCOMMIT TRANSACTION\n");
			ps.printf("\n");
		}
		catch(SQLException sqlE){
			String ErrorMessage="SQL exception: "+sqlE.getMessage()+"\n";
			System.err.printf(ErrorMessage);
			ps.printf(ErrorMessage);
		}
		catch (FileNotFoundException e){
			System.err.printf("Error on writing output %s file: %s\n", _fileName, e.getMessage());
		}
		finally{
			
			if(rsSc!=null) rsSc.close();
			if(rsTn!=null) rsTn.close();
			if(rsEx!=null) rsEx.close();
			if(rsPk!=null) rsPk.close();
			if(rsFk!=null) rsFk.close();
			// Connection Close
			if(con!=null) con.close();
			// File Close
			if(ps!=null) ps.close();
			}
	}
	

	private void printAlternateKeysSQL(PrintStream ps, Connection con, DatabaseMetaData dbmd) throws SQLException {
		ResultSet rs=null;
		try{
			ps.println("\n/* Alternate Keys Constraints */");
			rs = QueryExec(con, " SELECT" +
									" TC.CONSTRAINT_SCHEMA," +
									" TC.TABLE_NAME," +
									" CU.COLUMN_NAME," +
									" TC.CONSTRAINT_NAME" +
								" FROM" +
									" INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC," +
									" INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CU" +
								" WHERE" +
									" CONSTRAINT_TYPE='UNIQUE' AND" +
									" TC.CONSTRAINT_NAME=CU.CONSTRAINT_NAME");
			while(rs.next())
				ps.printf("ALTER TABLE [%s].[%s] ADD CONSTRAINT [%s] UNIQUE  (%s)\n", 
						rs.getString(1), rs.getString(2), rs.getString(4), rs.getString(3));
			ps.println();
		}
		catch(SQLException sqlE){
			String ErrorMessage="Ocurred a SQL exception: "+sqlE.getMessage()+"\nDiscard error if Database engine is not a SQLServer2008.";
			System.err.printf(ErrorMessage);
			ps.printf("/* "+ErrorMessage+" */\n");
		}
		finally{
			if(rs!=null) rs.close();	
		}
	}

	
	
	private void printConstraintsSQL(PrintStream ps, Connection con, DatabaseMetaData dbmd) throws SQLException {
		ResultSet rs=null;
		try{
			ps.println("\n/* Table Column Check Constraints */");
			rs = QueryExec(con," SELECT" +
									" CC.CONSTRAINT_SCHEMA," +
									" CU.TABLE_NAME," +
									" CC.CONSTRAINT_NAME," +
									" CC.CHECK_CLAUSE " +
								" FROM" +
									" INFORMATION_SCHEMA.CHECK_CONSTRAINTS CC," +
									" INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE CU" +
								" WHERE CC.CONSTRAINT_NAME=CU.CONSTRAINT_NAME");
			while(rs.next())
				ps.printf("ALTER TABLE [%s].[%s] ADD CONSTRAINT [%s] CHECK  %s\n", 
						rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			ps.println();
		}
		catch(SQLException sqlE){
			String ErrorMessage="Ocurred a SQL exception: "+sqlE.getMessage()+"\nDiscard error if Database engine is not a SQLServer2008.";
			System.err.printf(ErrorMessage);
			ps.printf("/* "+ErrorMessage+" */\n");
		}
		finally{
			if(rs!=null) rs.close();	
		}
	}

	/********** Print Foreign Keys 
	 * @throws SQLException 
	 * @throws SQLException *************/
	private void printForeignKeys(PrintStream ps, DatabaseMetaData dbmd, String schema, String tableName) throws SQLException {

		ResultSet rs=null;
		try{
			rs = dbmd.getImportedKeys(null, schema, tableName);
			String fkKeys="", pkKeys="", fkTable="";
	
			boolean first=true;
			String ref="%s )\n\t\tREFERENCES %s.%s ( %s )\n";
			String fkSchema="",fkName="";
			while(rs.next()){
	
				if(rs.getString("KEY_SEQ").compareTo("1")==0){
					
					if(!first)
						ps.printf(ref, fkKeys, fkSchema, fkTable, pkKeys);
					
					first=false;
					
					fkName=rs.getString("FK_NAME");
					ps.printf("\nALTER TABLE %s.%s ADD CONSTRAINT %s FOREIGN KEY ( ", schema, tableName, fkName);
					fkTable=rs.getString("PKTABLE_NAME");
					fkKeys=rs.getString("FKCOLUMN_NAME");
					pkKeys=rs.getString("PKCOLUMN_NAME");
					fkKeys=rs.getString("FKCOLUMN_NAME");
					pkKeys=rs.getString("PKCOLUMN_NAME");
					fkSchema=rs.getString("PKTABLE_SCHEM");
				}
				else{
					fkKeys=fkKeys+" , "+rs.getString("FKCOLUMN_NAME");
					pkKeys=pkKeys+" , "+rs.getString("PKCOLUMN_NAME");
				}
			}
			if(fkKeys.length()!=0)
				ps.printf(ref, fkKeys, fkSchema, fkTable, pkKeys);
		}
		catch(SQLException sqlE){
			String ErrorMessage="SQL exception: "+sqlE.getMessage();
			System.err.printf(ErrorMessage);
			ps.printf("/* "+ErrorMessage+" */\n");
		}
		finally{
			if(rs!=null) rs.close();	
		}
	}
		
	public static ResultSet QueryExec(Connection con, String sqlStat) throws SQLException {
		Statement stmt = con.createStatement();
		return stmt.executeQuery(sqlStat);
	}

	@Override
	public void clear() {
		_fileName=null;
	}
}
