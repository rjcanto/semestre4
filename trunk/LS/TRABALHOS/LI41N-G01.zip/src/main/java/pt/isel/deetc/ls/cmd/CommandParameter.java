package pt.isel.deetc.ls.cmd;

public abstract class CommandParameter {
	private final String _param;
	private final boolean _mandatory;
	private final String _alias;
	
	public CommandParameter(String param, boolean mandatory, String alias, boolean nullable){
		_param=param;
		_mandatory=mandatory;
		_alias=alias;
	}

	public CommandParameter(String param, boolean mandatory){
		this(param,mandatory,"",true);
	}

	public String getName(){
		return _param;
	}
	
	// If parameter has a non valid value, it should return false, otherwise it shall be true
	public abstract boolean setValue(String p); 
	public abstract String getValue(); // Should return null if no value was set

	public boolean isMandatory(){
		return _mandatory;
	}

	public String getDescription() {
		String msg="-"+getName()+" "+_alias;;
		if(!_mandatory)
			msg="["+msg+"]";	
		return msg;
	}
}
