package pt.isel.deetc.ls.mapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.gui.model.ExtendedCurricularUnit;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

public class CourseMapper extends Mapper<Course>{
	
	ContactoUCMapper cucm= new ContactoUCMapper(this.getConnection());
	CurricularUnitMapper cum = new CurricularUnitMapper(getConnection()); 
	
	public CourseMapper(Connection c) {
		super(c);
	}

	@Override
	public int delete(Course t) throws SQLException {
		PreparedStatement statement=null;
		int nDeleted=0;
		try{
			String cmdDelete = "DELETE FROM CURSO WHERE CURSO.acronimo = ?" ;
			statement = _c.prepareStatement(cmdDelete) ;
			statement.setString(1, t.getAcr()) ;
			nDeleted=statement.executeUpdate(); //TODO - manage a delete fault (because the constraints ....)
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nDeleted;
	}


	@Override
	public int insert(Course t) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("INSERT INTO CURSO"+
					"(acronimo, nome) values (?,?)") ;
			statement.setString(1, t.getAcr()) ;
			statement.setString(2, t.getNome()) ;
			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	@Override
	public int update(Course t) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		try{
			statement = _c.prepareStatement("UPDATE CURSO SET "+
					"CURSO.nome=? WHERE CURSO.acronimo=?") ;
			statement.setString(1, t.getAcr()) ;
			statement.setString(2, t.getNome()) ;
			nUpdated=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}
	
	@Override
	public List<Course> select() throws SQLException {
		PreparedStatement statement=null;
		List<Course> list = new LinkedList<Course>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT CURSO.acronimo, CURSO.nome "+
					"FROM CURSO") ;
			rs=statement.executeQuery();
			while(rs.next()) {
				list.add(new Course(rs.getString("acronimo"), rs.getString("nome"))) ;
			}
			return list;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	public Course selectAcronim(String acr) throws SQLException{
		PreparedStatement statement=null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT CURSO.acronimo, CURSO.nome "+
					"FROM CURSO WHERE CURSO.acronimo=?") ;
			statement.setString(1, acr) ;
			rs=statement.executeQuery();
			if(rs.next())
				return new Course(rs.getString("acronimo"), rs.getString("nome")) ;
			return null;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}		
	}

	public List<Course> selectName(String name) throws SQLException{
		PreparedStatement statement=null;
		LinkedList<Course> list = new LinkedList<Course>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT CURSO.acronimo, CURSO.nome "+
					"FROM CURSO WHERE CURSO.nome=?") ;
			statement.setString(1, name) ;
			rs=statement.executeQuery();
			if(rs.next())
				list.add(new Course(rs.getString("acronimo"), rs.getString("nome"))) ;
			return list;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}		
	}

	
	public Teacher selectOwner(Course c, Semester s) throws SQLException{
		PreparedStatement statement=null;
		if(s==null || c==null)
			return null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement(
					"SELECT  DISTINCT d.nome, d.numero, d.tipo, d.email FROM  DOCENTE as d"+ 
					" INNER JOIN HIST_PROF_CURSO as h"+
					" ON (d.numero=h.numDocente)"+ 
					" WHERE H.acrCurso=? " +
					" and (h.anoLectFim is null or h.anoLectFim >= ? )" +
					" and (h.semLectFim is null or h.semLectFim >= ?)"+
					" and (h.anoLectIni <= ?) and h.semLectIni <= ?") ;
			statement.setString(1, c.getAcr() ) ;
			statement.setString(2, s.getYear()) ;
			statement.setString(3, s.getSeason()) ;
			statement.setString(4, s.getYear()) ;
			statement.setString(5, s.getSeason()) ;

			rs=statement.executeQuery();
			if(rs.next()){
				return new Teacher(rs.getInt(2),rs.getString(1),rs.getString(4), rs.getString(3)); 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
		return null;
	}
	
	
	
	
	public List<ExtendedCurricularUnit> selectUC(Course c, Semester s) throws SQLException{
		PreparedStatement statement=null;
		LinkedList<ExtendedCurricularUnit> list = new LinkedList<ExtendedCurricularUnit>() ;
		if(s==null || c==null)
			return list;
		ResultSet rs;
		try{
			statement = _c.prepareStatement(
					"SELECT DISTINCT UC.acronimo, UC.nome, UC.creditos, H.caracter, H.semCurricular"+
					" FROM UC INNER JOIN HIST_CURSO_UC as H" +
					"  ON (UC.acronimo=H.acrUC)" +
					" WHERE H.acrCurso=? " +
					" and (h.anoLectFim is null or h.anoLectFim >= ? )" +
					" and (h.semLectFim is null or h.semLectFim >= ?)"+
					" and (h.anoLectIni <= ?) and h.semLectIni <= ?"+
					" ORDER BY H.semCurricular, H.caracter ") ;
			statement.setString(1, c.getAcr() ) ;
			statement.setString(2, s.getYear()) ;
			statement.setString(3, s.getSeason()) ;
			statement.setString(4, s.getYear()) ;
			statement.setString(5, s.getSeason()) ;

			rs=statement.executeQuery();
			while(rs.next()){
				CurricularUnit uc=new CurricularUnit(
						rs.getString(1), 
						rs.getString(2),
						rs.getInt(3));
				list.add(new ExtendedCurricularUnit(
						uc,
						rs.getString(4),
						rs.getInt(5), 
						cucm.select(rs.getString(1)),
						cum.select(uc, s)));
			}
			return list;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	

	public ExtendedCurricularUnit selectUcByAcr(String ucAcr, Course c, Semester s) throws SQLException{
		PreparedStatement statement=null;
		if(s==null || c==null)
			return null;
		ResultSet rs;
		try{
			statement = _c.prepareStatement(
					"SELECT DISTINCT UC.acronimo, UC.nome, UC.creditos, H.caracter, H.semCurricular"+
					" FROM UC INNER JOIN HIST_CURSO_UC as H" +
					"  ON (UC.acronimo=H.acrUC)" +
					" WHERE H.acrCurso=? and UC.acronimo = ?" +
					" and (h.anoLectFim is null or h.anoLectFim+h.semLectFim>= ?+? )" +
					" and ((h.anoLectIni+h.semLectIni) < (?+?))" +
					" ORDER BY H.semCurricular, H.caracter ") ;
			statement.setString(2, ucAcr ) ;
			statement.setString(1, c.getAcr() ) ;
			statement.setString(3, s.getYear()) ;
			statement.setString(4, s.getSeason()) ;
			statement.setString(5, s.getYear()) ;
			statement.setString(6, s.getSeason()) ;

			rs=statement.executeQuery();

			if(rs.next())
				return new ExtendedCurricularUnit(
						new CurricularUnit(
								rs.getString(1), 
								rs.getString(2),
								rs.getInt(3)),
						rs.getString(4),
						rs.getInt(5),
						cucm.select(rs.getString(1)));

			return null;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}

	
	
	
	
	public int selectCurrSemester(Course c, CurricularUnit uc) throws SQLException{
		PreparedStatement statement=null;
		int semCurricular = 0 ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT TOP 1 semCurricular "+
					"FROM HIST_CURSO_UC" +
					" WHERE acrCurso=? AND acrUC=? ORDER BY anoLectIni;") ;
			statement.setString(1, c.getAcr() ) ;
			statement.setString(2, uc.getAcronym() ) ;
			rs=statement.executeQuery();
			if(rs.next())
				semCurricular = rs.getInt("semCurricular") ;
			return semCurricular;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	public String selectType(Course c, CurricularUnit uc) throws SQLException{
		PreparedStatement statement=null;
		String resultType = null ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT TOP 1 caracter "+
					"FROM HIST_CURSO_UC" +
					" WHERE acrCurso=? AND acrUC=? ORDER BY anoLectIni DESC;") ;
			statement.setString(1, c.getAcr() ) ;
			statement.setString(2, uc.getAcronym() ) ;
			rs=statement.executeQuery();
			if(rs.next())
				resultType = rs.getString("caracter") ;
			return resultType;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	public Semester selectUCBeginSemester(Course c, CurricularUnit cu) throws SQLException, BadParameterException{
		PreparedStatement statement=null;
		ResultSet rs;
		SemesterMapper sMapper = new SemesterMapper(_c) ;
		try{
			statement = _c.prepareStatement("SELECT TOP 1 anoLectIni, semLectIni FROM HIST_CURSO_UC" +
					" WHERE acrCurso=? AND acrUC=? ORDER BY anoLectIni, semLectIni ASC") ;
			statement.setString(1, c.getAcr() ) ;
			statement.setString(2, cu.getAcronym() ) ;
			rs=statement.executeQuery();
			if(rs.next())
				return sMapper.selectSem(rs.getString("anoLectIni"), rs.getString("semLectIni")) ;
			return null ;	
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	public Semester selectUCEndSemester(Course c, CurricularUnit cu) throws SQLException, BadParameterException{
		PreparedStatement statement=null;
		ResultSet rs;
		SemesterMapper sMapper = new SemesterMapper(_c) ;
		try{
			statement = _c.prepareStatement("SELECT TOP 1 anoLectFim, semLectFim FROM HIST_CURSO_UC" +
					" WHERE acrCurso=? AND acrUC=? ORDER BY anoLectFIM DESC, semLectFim DESC") ;
			statement.setString(1, c.getAcr() ) ;
			statement.setString(2, cu.getAcronym() ) ;
			rs=statement.executeQuery();
			if(rs.next()) {
				if (rs.getString("anoLectFim") == null) return null;
				return sMapper.selectSem(rs.getString("anoLectFim"), rs.getString("semLectFim")) ;
			}
			return null ;	
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}
	
	@Override
	public boolean find(Course t) throws SQLException {
		PreparedStatement statement = null ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT CURSO.acronimo, CURSO.nome "+
					"FROM CURSO WHERE CURSO.acronimo=?") ;
			statement.setString(1, t.getAcr()) ;
			rs=statement.executeQuery() ;
			if(rs.next())
				return true ;
			return false ;
		}finally{
			if(statement!=null)
				statement.close() ;
		}
	}
	
	public boolean findActiveUCinCourse(Course c, CurricularUnit uc) throws SQLException {
		PreparedStatement statement = null ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement(
					"SELECT HIST_CURSO_UC.acrCurso, HIST_CURSO_UC.acrUC "+
					"FROM HIST_CURSO_UC " +
					"WHERE HIST_CURSO_UC.acrCurso=? AND HIST_CURSO_UC.acrUC=? " +
					"INTERSECT SELECT HIST_CURSO_UC.acrCurso, HIST_CURSO_UC.acrUC " + 
					"FROM HIST_CURSO_UC " +
					"WHERE HIST_CURSO_UC.semLectFim IS NULL AND HIST_CURSO_UC.anoLectFim IS NULL") ;
			statement.setString(1, c.getAcr()) ;
			statement.setString(2, uc.getAcronym()) ;
			rs=statement.executeQuery() ;
			if(rs.next())
				return true ;
			return false ;
		}finally{
			if(statement!=null)
				statement.close() ;
		}
	}



}
