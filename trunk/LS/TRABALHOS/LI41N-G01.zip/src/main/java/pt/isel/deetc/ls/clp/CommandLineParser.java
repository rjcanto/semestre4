package pt.isel.deetc.ls.clp;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * This class parses a command line arguments string given to the {@link #parse} method.
 * <p>
 * With the given command line string a {@link Map} is filled with the argument name being the key and the optional argument value 
 * being the map value. The command line arguments map is available as the return object from {@link #parse(String)} method or as the return object from 
 * {@link #getArguments()}.
 * </p>
 * <p>
 * The supported command line arguments String has the following format:
 * <code>{ARGUMENT_PREFIX&ltargument_name&gtARGUMENT_VALUE_SEPARATOR&ltargument_value&gt}*</code>.
 * Here is a sample command line string for the default argument prefix ({@link #DEFAULT_ARGUMENT_PREFIX} -> "-") and  argument value separator 
 * ({@link #DEFAULT_ARGUMENT_VALUE_SEPARATOR} -> " "):
 * <b>-argumet1 valueArgumen1 -argument2 valueArgument2</b>
 * </p>
 * <p>Each argument name and value are trimmed from leading and trailing spaces.</p>
 * 
 * @author Carlos Guedes, Lu�s Falc�o e Pedro F�lix
 * @version 1.0 - 19/02/2010
 */
public class CommandLineParser {
	public static final String DEFAULT_ARGUMENT_PREFIX = "-";
	public static final String DEFAULT_ARGUMENT_VALUE_SEPARATOR = " ";
	
	
	private final String _argumentPrefix;
	private final String _argumentValueSeparator;
	
	/**
	 * Initializes a new instance of the {@link #CommandLineParser} class with default argument prefix ({@link #DEFAULT_ARGUMENT_PREFIX} and default
	 * argument value separator {@link #DEFAULT_ARGUMENT_VALUE_SEPARATOR}.
	 */
	public CommandLineParser() {
		_argumentPrefix = DEFAULT_ARGUMENT_PREFIX;
		_argumentValueSeparator = DEFAULT_ARGUMENT_VALUE_SEPARATOR;
	}
	
	
	/**
	 * /**
	 * Initializes a new instance of the {@link #CommandLineParser} class with the given <code>argumentPrefix</code> and <code>argumentvalueseparator</code>  
	 *
	 * @param argumentPrefix The string that prefixes the argument name
	 * @param argumentValueSeparator The string that separates the argument name from its value.
	 */
	public CommandLineParser(String argumentPrefix, String argumentValueSeparator) {
		_argumentPrefix = argumentPrefix;
		_argumentValueSeparator = argumentValueSeparator;
	}
	
	
	/**
	 * Parses the given <code>commadLine</code> string array, fills the internal arguments map and returns it. 
	 * @param commandLine The command line string to be parsed
	 * @return The parsed arguments {@link Map}
	 */
	public Map<String, String> parse(String []args) {
		StringBuffer sb = new StringBuffer();
		if(args!= null) {
			for (String arg : args) {
				sb.append(arg + " ");
			}
		}
		return parse(sb.toString());
	}
	
	/**
	 * Parses the given <code>commadLine</code> string, fills the internal arguments map and returns it. 
	 * @param commandLine The command line string to be parsed
	 * @return The parsed arguments {@link Map}
	 */
	public Map<String, String> parse(String commandLine) {
		LinkedHashMap<String, String> argumentsMap = new LinkedHashMap<String, String>();
		if(commandLine != null) {
			String[] arguments = commandLine.split(_argumentPrefix);
			
			// Iterate through the split parameters. Skip the first position that has an empty string or the string till the first '-'
			for (int i = 1; i < arguments.length; ++i) {
				String argument = arguments[i];
				int idxSeparator = argument.indexOf(_argumentValueSeparator);
				
				String name = null;
				String value = "";
				if(idxSeparator == -1) {
					// Parameter with no value
					name = argument;
				} else {
					// Parameter with value
					// Parse the name removing (trimming) leading and trailing spaces 
					name = argument.substring(0, idxSeparator).trim();
					// Parse the value removing (trimming) leading and trailing spaces
					//Original Line
					//value = argument.substring(idxSeparator, argument.length()).trim();
					//Corrected Line.
					//Argument included separator. Now it passes the substring that starts
					//right after the separator.
					//Because the separator can have more than 1 char, we need to use is length.
					value = argument.substring(idxSeparator+_argumentValueSeparator.length(), argument.length()).trim();
				}
				argumentsMap.put(name, value);
			}
		}
		return argumentsMap;
	}
	
	public Map<String, Collection<String>> parseMultiple(String commandLine) {
		return null;
	}
}
