package pt.isel.deetc.ls.model;

public class Course {
	private final String _acr ;
	private final String _nome ;
	
	public Course(String a, String n) {
		_acr= a ;
		_nome= n;
	}
	
	public String getAcr(){
		return _acr ;
	}
	
	public String getNome(){
		return _nome ;
	}
	
	@Override
	public String toString(){
		return "\t"+_acr+"::"+_nome;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) 
			return false;
		
		if(obj.getClass() != getClass()){
			return false;
		}
		
		Course c = (Course) obj ;
		if (c._acr == this._acr)
			return true ;
		return false ;
	}

	@Override
	public int hashCode(){
		return _acr.hashCode();
	}

}
