package pt.isel.deetc.ls.cmd.etapa2;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;


public final class SetDefault extends Command {

	private final DefaultValues _df;

	public SetDefault(DefaultValues dv ) {
		super( "set", "Sets the default values for common command parameters", null );
		_df = dv;
		_df.addDefault("course", "LEIC");
		_df.addDefault("season", "ver");
		_df.addDefault("year", "09/10");
		_df.addDefault("output", "");
		_df.addDefault("view", "plain");
		getParameters( ).add( new CommandParameter( "course",false, "<course_name>", false ){
			public String getValue( ) { return _df.getDefault( this.getName( ) ); }
			public boolean setValue( String p ) { _df.addDefault( this.getName( ), p );return true;}
		} );
		getParameters( ).add( new CommandParameter( "season",false, "<semester_season>", false ){
			public String getValue( ) { return _df.getDefault( this.getName( ) ); }
			public boolean setValue( String p ) { _df.addDefault( this.getName( ), p ); return true;}
		} );
		getParameters( ).add( new CommandParameter( "year",false, "<semester_year>", false ){
			public String getValue( ) { return _df.getDefault( this.getName( ) ); }
			public boolean setValue( String p ) { _df.addDefault( this.getName( ), p ); return true;}
		} );
		getParameters( ).add( new CommandParameter( "output",false, "<file_name>", false ){
			public String getValue( ) { return _df.getDefault( this.getName( ) ); }
			public boolean setValue( String p ) { _df.addDefault( this.getName( ), p );return true;}
		} );
		getParameters( ).add( new CommandParameter( "view",false, "( html|plain )", false ){
			public String getValue( ) { return _df.getDefault( this.getName( ) ); }
			public boolean setValue( String p ) { 
				if( ( p.compareToIgnoreCase( "html" ) == 0 ) || ( p.compareToIgnoreCase( "plain" ) == 0 ) )
					_df.addDefault( this.getName( ), p.toLowerCase( ) );
				else{
					System.out.println(p+" is not a valid value");
					return false;
				}
				return true;
			}
		} );
	}

	@Override
	public void run( ) {
		System.out.println( "Default values:" );
		for( CommandParameter cp: this.getParameters( ) ) 
			System.out.println( "\t"
					+ cp.getName( )
					+ " = "
					+ ( cp.getValue( ) == null ? "<empty>" : cp.getValue( ) ) );
		
		/* This command must implement:
		 * -course <name>
		 * -output <fileName> 
		 * -view <format>
		 */
	}

	@Override
	public void clear( ) { }

}
