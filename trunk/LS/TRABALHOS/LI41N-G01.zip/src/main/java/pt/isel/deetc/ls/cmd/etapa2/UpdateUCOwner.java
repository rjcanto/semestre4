package pt.isel.deetc.ls.cmd.etapa2;


import java.sql.Connection;
import java.sql.SQLException;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;


import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class UpdateUCOwner extends Command {
	private String _nm;
	private String _acr;
	private String _semYear;
	private String _semSeason;

	public UpdateUCOwner(SQLServerDataSource dts, String nm, 
			String acr, String semYear, String semSeason) throws SQLException{
		this(dts);
		_nm=nm; _acr=acr; _semYear=semYear; _semSeason=semSeason;
		run();
	}
	
	public UpdateUCOwner(SQLServerDataSource dts) {
		super("uucowner","Updates the UC Owner", dts);
		clear();
		getParameters().add(new CommandParameter("nm",true,"<teacher_number>",false){
			public String getValue() { return _nm; }
			public boolean setValue(String p) { _nm=p; return true; }
		});
		getParameters().add(new CommandParameter("acr",true,"<acronym>",false){
			public String getValue() { return _acr; }
			public boolean setValue(String p) { _acr=p; return true; }
		});
		getParameters().add(new CommandParameter("year",true,"<semester_year>",false){
			public String getValue() { return _semYear; }
			public boolean setValue(String p) { _semYear=p; return true; }
		});
		getParameters().add(new CommandParameter("season",true,"<semester_season>",false){
			public String getValue() { return _semSeason; }
			public boolean setValue(String p) { _semSeason=p; return true; }
		});
	}

	@Override
	public void clear() {
		_nm = _acr = _semYear =_semSeason = null;

	}

	@Override
	public void run() throws SQLException{
		Connection conn =  getDts().getConnection();
		TeacherMapper tMapper = new TeacherMapper(conn) ;
		Teacher t=tMapper.selectNumber(Integer.parseInt(_nm.trim()));
		CurricularUnitMapper cm=new CurricularUnitMapper(conn);
		CurricularUnit c=cm.selectAcronimo(_acr);
		Semester s ;
		try{
			s=(new SemesterMapper(conn)).selectSem(_semYear, _semSeason);
		}
		catch(BadParameterException e){
			Utils.writeUserError("Invalid Year or Season", "Please verify Semester Year or Season");
			clear();
			if(conn!=null)
				conn.close();
			return;
		}
		cm.updateOwner(c, t, s);
		clear();
		if(conn!=null)
			conn.close();
	}
}
