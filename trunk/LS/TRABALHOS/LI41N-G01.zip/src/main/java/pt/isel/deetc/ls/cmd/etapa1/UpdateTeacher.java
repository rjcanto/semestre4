/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 

package pt.isel.deetc.ls.cmd.etapa1;

import java.sql.Connection;
import java.sql.SQLException;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.Teacher;


import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class UpdateTeacher extends Command {
	private String _nTeacher=null;
	private String _nm=null;
	private String _name=null;
	private String _email=null;
	private String _type=null;
	
	public void setTeacher(String nTeacher) {
		_nTeacher=nTeacher ;
	}
	public void setNumber(String nm) {
		_nm=nm ;
	}
	public void setName(String name) {
		_name=name ;
	}
	public void setEmail(String email) {
		_email=email ;
	}
	public void setType(String type) {
		_type=type ;
	}
	
	public UpdateTeacher(SQLServerDataSource dts) {
		super("udoc", "Updates an owner from the Database", dts);
		getParameters().add(new CommandParameter("owner",true,"<number>",false){
			public String getValue() { return _nTeacher; }
			public boolean setValue(String p) { _nTeacher=p; return true;}
		});
		getParameters().add(new CommandParameter("nm",false,"<number>",false){
			public String getValue() { return _nm; }
			public boolean setValue(String p) { _nm=p; return true;}
		});
		getParameters().add(new CommandParameter("name",false,"<name>",false){
			public String getValue() { return _name; }
			public boolean setValue(String p) { _name=p;return true; }
		});
		getParameters().add(new CommandParameter("email",false,"<email_address>",false){
			public String getValue() { return _email; }
			public boolean setValue(String p) { _email=p;return true; }
		});
		getParameters().add(new CommandParameter("type",false,"<teacher_type>",false){
			public String getValue() { return _type; }
			public boolean setValue(String p) { _type=p;return true; }
		});
	}

	public void run() throws SQLException{
		int nTeacher = Integer.valueOf(_nTeacher).intValue() ;
		int nUpdates = 0 ;
		Connection con = getDts().getConnection();
		try{
			TeacherMapper tMapper = new TeacherMapper(con) ;
			Teacher tOriginal = tMapper.selectNumber(nTeacher) ;
			con.setAutoCommit(false);
			if (_nm != null) {
				nUpdates=tMapper.update(nTeacher, new Teacher(
										(new Integer(_nm)).intValue(),
										tOriginal.getNOME(),
										tOriginal.getEMAIL(),
										tOriginal.getTIPO())) ;
			}
			if (_name != null) {
				nUpdates=tMapper.update(new Teacher(
								tOriginal.getNBRMEC(),
								_name,
								tOriginal.getEMAIL(),
								tOriginal.getTIPO())) ;
			}
			if (_email != null) {
				nUpdates=tMapper.update(new Teacher(
								tOriginal.getNBRMEC(),
								tOriginal.getNOME(),
								_email,
								tOriginal.getTIPO())) ;
			}
			if (_type != null && tOriginal.validateTipo(_type)) {;
				nUpdates=tMapper.update(new Teacher(
								tOriginal.getNBRMEC(),
								tOriginal.getNOME(),
								tOriginal.getEMAIL(),
								_type)) ;
			}
			con.commit();
			con.setAutoCommit(true);
			System.out.println((nUpdates==0?"Uns":"S")+"uccessfull update");
		}
		finally{
			con.close();
		}
	}

	@Override
	public void clear() { 

	}

}
