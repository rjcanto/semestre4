package pt.isel.deetc.ls.cmd.etapa2;

import java.sql.Connection;
import java.sql.SQLException;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.common.Utils;

import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;

import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;


public class ChangeUCReponsible extends Command{
	private String _tn,_uc,_sm,_year;
	public ChangeUCReponsible(SQLServerDataSource dts) {
		super("change", "Changes the responsible of a Curricular Unit", dts);
		clear();
		getParameters().add(new CommandParameter("tn",true,"<teacher_number>",false){
			public String getValue() { return _tn; }
			public boolean setValue(String p) { _tn=p; return true; }
		});
		getParameters().add(new CommandParameter("uc",true,"<uc_acronym>",false){
			public String getValue() { return _uc; }
			public boolean setValue(String p) { _uc=p; return true; }
		});
		getParameters().add(new CommandParameter("season",true,"<semester>",false){
			public String getValue() { return _sm; }
			public boolean setValue(String p) { _sm=p; return true; }
		});
		getParameters().add(new CommandParameter("year",true,"<year>",false){
			public String getValue() { return _year; }
			public boolean setValue(String p) { _year=p; return true; }
		});
		clear();
	}
	
	public void setUC(String uc){
		_uc=uc;
	}
	public void setSeason(String sm){
		_sm=sm;
	}
	public void setTeacher(String tn){
		_tn=tn;
	}

	public void setYear(String y){
		_year=y;
	}

	@Override
	public void clear() { _tn=_uc=_sm=null;}

	@Override
	public void run() throws SQLException  {
		Connection conn =  getDts().getConnection();
		TeacherMapper tm = new TeacherMapper(conn );
		Teacher t;
		CurricularUnit cu;
		CurricularUnitMapper cum=new CurricularUnitMapper(conn);
		if((cu=cum.selectAcronimo(_uc))==null){
			Utils.writeUserError("Invalid UC Acronym", "Please use a valid UC Acronym");
			return;
		}
		if((t=tm.selectNumber(Integer.parseInt(_tn.trim())))==null){
			Utils.writeUserError("Invalid Teacher Number", "Please use a valid Teacher Number");
			return;
		}
		Semester se;

		try{
			SemesterMapper sm=new SemesterMapper(conn);
			if((se=sm.selectSem(_year,_sm))==null){
				Utils.writeUserError("Invalid Year/Season", "Please use a valid Year/Season");
				return;
			}
		}
		catch (BadParameterException e){
			clear();
			return;
		}		
		(new CurricularUnitMapper(conn)).updateOwner(cu, t, se);		
		clear();
	}

}
