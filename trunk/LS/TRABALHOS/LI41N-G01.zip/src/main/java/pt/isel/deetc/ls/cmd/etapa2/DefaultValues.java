package pt.isel.deetc.ls.cmd.etapa2;

import java.util.LinkedHashMap;
import java.util.Map;

public class DefaultValues {
	private Map<String, String>_defaultValues;
	public DefaultValues(){
		_defaultValues=new LinkedHashMap<String, String>();
	}
	public boolean isPresent(String key){
		return _defaultValues.containsKey(key);
	}
	public String getDefault(String key){
		return _defaultValues.get(key);
	}
	public void addDefault(String key, String val){
		_defaultValues.remove(key);
		_defaultValues.put(key, val);		
	}
}
