/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ package pt.isel.deetc.ls.cmd;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.security.InvalidParameterException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

/* Objective: "Gerar script com instru��es SQL DML (Data Manipulation Language)
 * necess�rias para inserir o conte�do actual da base de dados." 
 * Command: "etapa0 -gen_dml <output_file_path>"
*/
public class ExtractDBData extends Command{
	// Instance fields
	private String _fileName=null;
	
	public ExtractDBData(SQLServerDataSource dts){
		super("gen_dml", "Produces a DML file with all inserts required to populate database", dts);
		getParameters().add(new CommandParameter("output",true,"<output_file_path>",false){

			@Override
			public String getValue() {
				return _fileName;
			}

			@Override
			public boolean setValue(String p) {
				_fileName=p; return true;
			}
		});
	}
	
	public void run() throws SQLException, InvalidParameterException{
		
		PrintStream ps  = null;
		Connection con  = null;
		ResultSet rsTn = null, rsEx = null, rsSc = null, rsPk=null, rsFk = null;
		
		try{
			
			ps = new PrintStream(new FileOutputStream(_fileName));
			con=getDts().getConnection();
			ps.printf("USE LS2;\n\nBEGIN TRANSACTION;\n\n");
			String [] tables = {"DOCENTE", "UC", "CURSO", "SEMLECTIVO", "CONTACTO_UC", "HIST_CURSO_UC", "HIST_PROF_UC", "HIST_DOC_UC", "HIST_PROF_CURSO"};		
			for(String tn: tables){			
				rsEx = GenerateDBSchema.QueryExec(con, "Select * from "+tn);
				int colCount=rsEx.getMetaData().getColumnCount();
				String sep;
				while(rsEx.next()){
					ps.print("INSERT INTO "+tn+" VALUES (");
					sep="";
					for (int i = 1; i <= colCount; i++){
						ps.print(sep+"'"+rsEx.getString(i)+"'");
						sep=",";
					}
					ps.println(");");
				}
			}
			rsEx.close();
			ps.printf("\n\nCOMMIT TRANSACTION;\n");
		}
		catch(SQLException sqlE){
			String ErrorMessage="SQL exception: "+sqlE.getMessage()+"\n";
			System.err.printf(ErrorMessage);
			ps.printf(ErrorMessage);
		}
		catch (FileNotFoundException e){
			System.err.printf("Error on writing output %s file: %s\n", _fileName, e.getMessage());
		}
		finally{
			
			if(rsSc!=null) rsSc.close();
			if(rsTn!=null) rsTn.close();
			if(rsEx!=null) rsEx.close();
			if(rsPk!=null) rsPk.close();
			if(rsFk!=null) rsFk.close();
			// Connection Close
			if(con!=null) con.close();
			// File Close
			if(ps!=null) ps.close();
			}
	}

	@Override
	public void clear() {
		_fileName=null;	
	}
	
}
	
