package pt.isel.deetc.ls.cmd.etapa2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandParameter;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.common.Utils;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class AssociateUCCourse extends Command {
	private String _uc;
	private String _course;
	private String _semLect;
	private String _yearLect;
	private String _semCurr;
	private String _caracter;

	public AssociateUCCourse(SQLServerDataSource dts){
		super("associate","Associates a UC to a specific course", dts);
		getParameters().add(new CommandParameter("uc",true, "<uc_acronym>", false){
			public String getValue() { return _uc; }
			public boolean setValue(String p) { _uc=p; return true; }
		});
		getParameters().add(new CommandParameter("course",true, "<course_acronym>", false){
			public String getValue() { return _course; }
			public boolean setValue(String p) {	_course=p; return true; }
		});
		getParameters().add(new CommandParameter("season",true, "<semester_lective>", false){
			public String getValue() { return _semLect; }
			public boolean setValue(String p) { _semLect=p; return true; }
		});
		getParameters().add(new CommandParameter("year",true, "<year_lective>", false){
			public String getValue() { return _yearLect; }
			public boolean setValue(String p) { _yearLect=p; return true; }
		});
		getParameters().add(new CommandParameter("sem_curr",true, "<semester_current>", false){
			public String getValue() { return _semCurr; }
			public boolean setValue(String p) { _semCurr=p; return true; }
		});
		getParameters().add(new CommandParameter("caracter",true, "<caracter>", false){
			public String getValue() { return _caracter; }
			public boolean setValue(String p) { _caracter=p; return true; }
		});
	}
	
	@Override
	public void clear() {
		_uc=null;
		_course=null;
		_semLect=null;
		_yearLect=null;
		_semCurr=null;
		_caracter=null;
	}

	public void setUC(String uc) { _uc=uc;}
	public void setCourse(String c){ _course=c;}
	public void setSemLect(String s ){ _semLect=s;}
	public void setYearLect(String y){_yearLect=y;}
	public void setSemCurr(String s){ _semCurr=s;}
	public void setCaracter(String c){ _caracter=c;}


	
	
	@Override
	public void run() throws SQLException, FileNotFoundException, IOException {

		Connection conn =  getDts().getConnection();
		CourseMapper com = new CourseMapper(conn );
		Course co;
		CurricularUnit cu;
		Semester se;
		if((co=com.selectAcronim(_course))==null){
			Utils.writeUserError("Invalid Course Acronym", "Please use a valid Acronym");
			return;
		}
		CurricularUnitMapper cum = new CurricularUnitMapper( conn );

		if((cu=cum.selectAcronimo(_uc))==null){
			Utils.writeUserError("Invalid UC Acronym", "Please use a valid UC Acronym");
			return;
		}
		try{
			SemesterMapper sem = new SemesterMapper( conn ); 
			if((se = sem.selectSem(_yearLect, _semLect ))==null){
				Utils.writeUserError("Invalid Lective Year or Semester", "Please review parameters");
				return;
			}
		}
		catch(BadParameterException e){
			Utils.writeUserError("Invalid parameter", "Please verify parameters");
			clear();
			if(conn!=null)
				conn.close();
			return;
		}
		cum.insert(cu, co, se, Integer.valueOf(_semCurr), _caracter);
		clear();
		if(conn!=null)
			conn.close();
	}
}
