package pt.isel.deetc.ls.model;

public class Teacher {
	private int _numero;
	private String _nome;
	private String _email;
	private String _tipo;
	
	public Teacher(int nbr, String n, String e, String t){
		_numero=nbr;
		_nome=n;
		_email=e;
		_tipo=t.toLowerCase();
	}

	public void setNBRMEC(int n) {
		_numero=n;
	}

	public void setNOME(String n) {
		 _nome=n;
	}

	public void setEMAIL(String e) {
		 _email=e;
	}
	
	public void setTIPO(String t) {
		 _tipo=t ;
	}

	public int getNBRMEC() {
		return _numero;
	}

	public String getNOME() {
		return _nome;
	}

	public String getEMAIL() {
		return _email;
	}
	
	public String getTIPO() {
		return _tipo ;
	}

	public boolean validateTipo(String tipo) {
		return (tipo.equalsIgnoreCase("professor") || tipo.equalsIgnoreCase("assistente")?true:false) ;
	}
	
	@Override
	public String toString() {
		return "\t"+_numero+"::"+_nome+"::"+_email+"::"+_tipo;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
			return false ;
		
		if(obj.getClass() != getClass())
			return false ;
		
		Teacher t = (Teacher) obj ;
		return (t._nome.equalsIgnoreCase(this._nome) 
				&& t._email.equalsIgnoreCase(this._email)
				&& t._tipo.equalsIgnoreCase(this._tipo)
				&& (t._numero==this._numero)
		);
	}
	
	@Override
	public int hashCode(){
		return (_nome.hashCode()+_email.hashCode()+_tipo.hashCode()+String.valueOf(_numero).hashCode());
	}

}
