package pt.isel.deetc.ls.model;

import java.sql.Date;

import pt.isel.deetc.ls.common.BadParameterException;

public class Semester {
	private final String _year ;
	private final String _season ;
	private final Date _begin ;
	private final Date _end ;
	
	public Semester(String y, String s, Date b, Date e) throws BadParameterException {
		if (!validateYear(y) || !validateSeason(s))
			throw new BadParameterException() ;
		_year = y ;
		_season = s.toLowerCase() ; ;
		_begin = b ;
		_end = e ;
	}
	
	public String getYear() {
		return _year ;
	}
	
	public String getSeason() {
		return _season ;
	}
	
	public Date getBegin() {
		return _begin ;
	}
	
	public Date getEnd() {
		return _end ;
	}
	
	public int compareBeginTo(Semester s) {
		return (this._begin.compareTo(s._begin)) ;
	}
	
	public int compareEndTo(Semester s) {
		return (this._end.compareTo(s._end)) ;
	}
	
	/**
	 * Validates if a String is in the form necessary by the DB model.
	 * @param year - the String which will be validated
	 * @return true if the String is in the form yy/yy, false otherwise.
	 */
	protected boolean validateYear(String year) {
		if (year.length() > 5 || year.charAt(2)!= '/') return false ;
		try {
			Integer firstYear = Integer.valueOf(year.substring(0, 2)) ;
			Integer secondYear = Integer.valueOf(year.substring(3)) ;
			if ((secondYear.intValue() - firstYear.intValue()) > 1) return false ;
			return true ;
		} catch (NumberFormatException e) {
			return false ;
		}
			
	}
	
	/**
	 * Validates that the string presented as argument is a semester season ("ver" or "inv")
	 * @param season - the String which will be validated
	 * @return true if the String is "ver" or "inv", false otherwise
	 */
	protected boolean validateSeason(String season) {
		return (season != "ver" || season != "inv") ? true : false;
	}
	
	@Override
	public String toString(){
		return _year+" "+_season;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) 
			return false;
		
		if(obj.getClass() != getClass()){
			return false;
		}
		
		Semester s = (Semester) obj ;
		return (s._season.matches(this._season) && s._year.matches(this._year)) ? true:false;
	}
	
	@Override
	public int hashCode(){
		return (_season.hashCode()+_year.hashCode());
	}
	
}
