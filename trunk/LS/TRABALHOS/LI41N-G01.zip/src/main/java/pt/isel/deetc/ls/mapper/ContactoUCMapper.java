package pt.isel.deetc.ls.mapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import pt.isel.deetc.ls.model.ContactoUC;

public class ContactoUCMapper extends Mapper<ContactoUC>{

	public ContactoUCMapper(Connection c) {
		super(c);
	}

	@Override
	public int delete(ContactoUC cuc) throws SQLException {
		PreparedStatement statement=null;
		int nDeleted=0;
		try{
			String cmdDelete = "DELETE FROM CONTACTO_UC WHERE acrUC = ? AND tipo=?;" ;
			statement = _c.prepareStatement(cmdDelete) ;
			statement.setString(1, cuc.getAcr()) ;
			statement.setString(2, cuc.getType()) ;
			nDeleted=statement.executeUpdate(); //TODO - manage a delete fault (because the constraints ....)
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nDeleted;
	}

	@Override
	public int insert(ContactoUC cuc) throws SQLException {
		PreparedStatement statement=null;
		int nInserted=0;
		try{
			statement = _c.prepareStatement("INSERT INTO CONTACTO_UC "+
					"(acrUC, tipo, horas) values (?,?,?)") ;
			statement.setString(1, cuc.getAcr()) ;
			statement.setString(2, cuc.getType()) ;
			statement.setDouble(3, cuc.getHours()) ;
			nInserted=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nInserted;
	}

	@Override
	public int update(ContactoUC cuc) throws SQLException {
		PreparedStatement statement=null;
		int nUpdated=0;
		try{
			statement = _c.prepareStatement("UPDATE CONTACTO_UC SET "+
					"horas=? WHERE acrUC=? AND tipo=?;") ;
			statement.setDouble(1, cuc.getHours()) ;
			statement.setString(2, cuc.getAcr()) ;
			statement.setString(3, cuc.getType()) ;
			nUpdated=statement.executeUpdate();
		}
		finally{
			if(statement!=null) statement.close();
		}
		return nUpdated;
	}

	@Override
	public boolean find(ContactoUC cuc) throws SQLException {
		PreparedStatement statement = null ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT acrUC "+
					"FROM CONTACTO_UC WHERE acrUC=? AND tipo=?;") ;
			statement.setString(1, cuc.getAcr()) ;
			statement.setString(2, cuc.getType()) ;
			rs=statement.executeQuery() ;
			if(rs.next())
				return true ;
			return false ;
		}finally{
			if(statement!=null)
				statement.close() ;
		}
	}

	@Override
	public List<ContactoUC> select() throws SQLException {
		PreparedStatement statement=null;
		List<ContactoUC> list = new LinkedList<ContactoUC>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT acrUC, tipo, horas "+
					"FROM CONTACTO_UC") ;
			rs=statement.executeQuery();
			while(rs.next()) {
				list.add(new ContactoUC(
					rs.getDouble("horas"),
					rs.getString("tipo"),
					rs.getString("acrUC"))) ;
			}
			return list;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}

	public List<ContactoUC> select(String acr) throws SQLException {
		PreparedStatement statement=null;
		List<ContactoUC> list = new LinkedList<ContactoUC>() ;
		ResultSet rs;
		try{
			statement = _c.prepareStatement("SELECT acrUC, tipo, horas "+
					"FROM CONTACTO_UC WHERE acrUC=?") ;
			statement.setString(1, acr) ;
			rs=statement.executeQuery();
			while(rs.next()) {
				list.add(new ContactoUC(
					rs.getDouble("horas"),
					rs.getString("tipo"),
					rs.getString("acrUC"))) ;
			}
			return list;
		}
		finally{
			if(statement!=null) 
				statement.close();
		}
	}

	
	
	
}
