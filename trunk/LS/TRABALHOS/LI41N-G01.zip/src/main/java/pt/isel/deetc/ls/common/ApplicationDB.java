package pt.isel.deetc.ls.common;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class ApplicationDB {

	private final SQLServerDataSource dts;
	private final Properties glpr;
	public ApplicationDB() {
		dts = new SQLServerDataSource();
		glpr = new GlobalProperties();
		String ConnectionStr = glpr.getProperty("connstring");
		if(ConnectionStr!=null){
			dts.setURL(ConnectionStr);
//		System.out.println(ConnectionStr);
		}
		else{
			dts.setServerName(glpr.getProperty("server","localhost"));
			dts.setPortNumber(Integer.parseInt(glpr.getProperty("port","1433")));
			dts.setDatabaseName(glpr.getProperty("database","LS2"));
			dts.setUser(glpr.getProperty("user","LS"));
			dts.setPassword(glpr.getProperty("password","LS"));
		}
	}
	
	public SQLServerDataSource getDataSource(){
		return dts;
	}
	
	
	class GlobalProperties extends Properties{
		private static final long serialVersionUID = 5050028990833877200L; 
		public GlobalProperties() {
			super();
			try{
				FileInputStream in = new FileInputStream("app.properties");				
				this.load(in);
			}
			catch ( IOException e){
				Utils.writeUserError("Reading File", "File name: \"app.properties\"");
				throw new ApplicationExitException();
			}
		}
	}
}
