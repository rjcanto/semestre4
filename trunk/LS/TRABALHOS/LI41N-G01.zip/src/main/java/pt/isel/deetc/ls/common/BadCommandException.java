package pt.isel.deetc.ls.common;

public class BadCommandException extends Exception {

	/**
	 * 
	 */
	private String _msg;
	private static final long serialVersionUID = 1L;
	public BadCommandException(){
		_msg = "use: -help";
	}
	public BadCommandException(String s){
		_msg = s;
	}
	public String getMessage(){
		return _msg;
	}
}
