package pt.isel.deetc.ls.cmd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import pt.isel.deetc.ls.common.Utils;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;


public class CreateDB extends Command{


	private Connection _con=null;
	private boolean _force=false; 
	
	public CreateDB(SQLServerDataSource dts){
		super("create","Creates a database and creates tables", dts);
		getParameters().add(new CommandParameter("force",false){
			public String getValue() { return ""; }
			public boolean setValue(String p) { _force=true; return true; }
		});
	}

	public CreateDB(SQLServerDataSource dts, boolean force){
		this(dts);
		_force=force;
	}

	public void connect() throws SQLServerException{
		_con=getDts().getConnection();
	}
	public void disconnect() throws SQLException{
		_con.close();
	}

	public void run() throws SQLException, IOException{
		
		try{
			connect();
			if(_force)
				runSQLFile("_DropDBTables.sql");
			runSQLFile("_CreateDBTables.sql");
		}
		catch(SQLException e){
			Utils.writeUserError("Database fault or database tables already exists", "Try option: -force");

		}
		finally{
			disconnect();			
		}

	}

	private void DDLExec(String sqlStat) throws SQLException {
		Statement stmt = _con.createStatement();
		stmt.executeUpdate(sqlStat);
		stmt.close();
	}

	public void clear() {_force=false;}
	
	
	/*
	 * The SQL file that supports this method, shall include a ";" string after each 
	 * DDL command, otherwise, the statement that does not finishes with a ";" will not
	 * be execute, and can generate a SQL error.
	 */
	private void runSQLFile(String str) throws SQLException, IOException {
		BufferedReader in = null;
		InputStream is = ClassLoader.getSystemResourceAsStream(str);
		if(is==null){
			System.err.println("Error on opening or reading "+str+" file.");
			return;
		}
		in =  new BufferedReader(new InputStreamReader(is));
		String line;
		StringBuffer sb=new StringBuffer();
		while((line=in.readLine())!=null){
			sb.append(line+" ");
			if(line.contains(";")){
				DDLExec(sb.toString());
				sb=new StringBuffer();
			}
		}
	}
}

