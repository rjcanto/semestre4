package pt.isel.deetc.ls.common;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import pt.isel.deetc.ls.model.ContactoUC;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Teacher;

public class FileParser {
	/*
	 private FileRecordNode<UnidadeCurricular> ucRecord=null;
	 
	 private FileRecordNode<Docente> docRecord=null;
	*/
	private LinkedList<CurricularUnit> ucRecord ;
	private LinkedList<Teacher> docRecord ;
	private LinkedList<ContactoUC> contactUcRecord ;
	private BufferedReader fileReader=null;
	private String line=null;
	private int nLine=0;

	
	/**
	 * Constructor que recebe um ficheiro de entrada.
	 * @param filename
	 * @throws FileNotFoundException 
	 * @throws IOException 
	 */
	public FileParser(String filename) throws FileNotFoundException  {
		ucRecord=new LinkedList<CurricularUnit>();
		docRecord=new LinkedList<Teacher>();
		contactUcRecord=new LinkedList<ContactoUC>() ;
		fileReader = new BufferedReader(new FileReader(filename));
		try {
			loadDocente() ;
			loadUnidadeCurricular() ;
		}
		catch (IOException e)
		{
			Utils.writeUserError("Error on reading "+filename+" file.", "");
		}
//		} catch (IOException e) {
//			System.err.println("Error on opening or reading "+filename+" file.");;
//		}
	}
	/**
	 * @return FileRecordNode<UnidadeCurricular>
	 * Lista simplesmente ligada, que contem os registos do tipo Unidade Curricular.
	 */
	public LinkedList<CurricularUnit> getUnidadesCurriculares(){
		return ucRecord;
	}
	/**
	 * 
	 * @return LinkedList<Docente>
	 * Lista simplesmente ligada, que contem os registos do tipo Docente. 
	 */
	public LinkedList<Teacher> getDocentes(){
		return docRecord;
	}
	
	/**
	 * Lista simplesmente ligada, que contem os registos do tipo HoraTipo.
	 * @return LinkedList<HorasTipo>
	 */
	public LinkedList<ContactoUC> getContactoUc() {
		return contactUcRecord;
	}
	
	/**
	 * 
	 * @param s
	 * @param acronimo
	 * @return
	 */
	private LinkedList<ContactoUC> loadContactoUC(String s, String acronimo){
		if (s.isEmpty()) return null ;
		String[] lineFields=s.split("[#]");
		for (int i=0;i<lineFields.length;++i){
			String[] pair=lineFields[i].split("[:]");
			
			Double nbr=CustomNumber.parseDouble(pair[1].trim());
			ContactoUC temp = new ContactoUC(nbr, pair[0], acronimo) ;
			contactUcRecord.add(temp);
			pair=null;
		}
		return contactUcRecord ;
	}
	
	private void loadDocente() throws IOException {
		while ((line=fileReader.readLine())!= null){
			++nLine;
			if (line.isEmpty()) break;
			
			String[] lineFields=line.split("[|]");
			
			for (int i=0;i< lineFields.length;++i)
				if (lineFields[i].isEmpty())
				 System.out.format("[%d]:: Linha com o campo [%d] vazio,\n",nLine,i);
			
			//N�o existe informa��o sobre o tipo de docente. Assume-se como sendo professor.
			Teacher doc=new Teacher(
							Integer.parseInt(lineFields[0]), 
							lineFields[1], 
							lineFields[2],
							"Professor");
			docRecord.add(doc);
		}
	}
	
	private void loadUnidadeCurricular() throws IOException {
		while ((line=fileReader.readLine())!= null){
			++nLine;
			if (line.isEmpty()) continue;
			
			String[] lineFields=line.split("[|]");

			for (int i=0;i< lineFields.length;++i)
				if (lineFields[i].isEmpty())
					System.out.format("[%d]:: Linha com o campo [%d] vazio,\n",nLine,i);	
			CurricularUnit uc=new CurricularUnit(
					lineFields[0], 
					lineFields[4], 
					Integer.parseInt(lineFields[2])
			);
			loadContactoUC(lineFields[3],lineFields[0]) ;
			ucRecord.add(uc);
		}
	}
}
