/* ISEL - DEETC - LEIC - LS
 * Laborat�rio de Software
 * LI41N-PSC 2009/2010
 * Data: 02.04.2010
 * Alunos
 * N� 30896 : Ricardo Canto
 * N� 10044 : Jos� Costa
 */ 
package pt.isel.deetc.ls.cmd;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;


/**
 * This class defines the contract (as an abstract class) for commands.
 *  
 * @author Ricardo Canto, Jos� Costa
 * @version 1.0 - 26/06/2010
 */
public abstract class Command {
	    private final String _cmdName;
	    private final String _description;
	    private final SQLServerDataSource _dts;
	    private final List<CommandParameter>  _params;


		/**
		 * Class constructor
		 * @param name Command name  
		 * @param description Command description
		 * @param dts DataSource used on the commands execution   
		 */
	    public Command(String name, String description, SQLServerDataSource dts){
	    	_cmdName=name;
			_dts=dts;
		    _params=new ArrayList<CommandParameter>();
		    _description=description;
	    }

		/**
		 * Class constructor
		 * @param name Command name  
		 * @param dts DataSource used on the commands execution   
		 */
	    public Command(String name, SQLServerDataSource dts){
	    	this(name, "", dts);
	    }

	    /**
		 * Class constructor
		 * @param name Command name  
		 * @param description Command description
		 */
	    public Command(String name, String description){
	    	this(name, description, null);
	    }

	    /**
		 * Class constructor
		 * @param name Command name  
		 */
	    public Command(String name){
	    	this(name, "", null);
	    }

	    /**
		 * Getter from command name field
		 */
	    public String getName(){
	    	return _cmdName;
	    }

	    /**
		 * Getter for DataSource field
		 */
	    public SQLServerDataSource getDts(){
	    	return _dts;
	    }
	    
	    /**
		 * Getter for the List that contains the command parameters
		 */
	    public  List<CommandParameter> getParameters(){
	    	return _params;
	    }
	    
	    /**
		 * Getter for the Command description field
		 */
	    public String getDescription(){
	    	return _description;
	    }
	    
	    /**
		 * Method responsible to build a String that describes the command usage
		 */
	    public String usage(){
			StringBuffer sb = new StringBuffer();
			for(CommandParameter cp: _params){
				sb.append(" ");
				sb.append(cp.getDescription());
			}
			return "-"+getName()+sb;
		}

	    /**
		 * Method responsible to run the command. This abstract method 
		 */
	    public abstract void run() throws SQLException, FileNotFoundException, IOException;

	    /**
		 * Method responsible to clear all fields. This method shall be called at the end of run() method 
		 */
	    public abstract void clear();    
 }
