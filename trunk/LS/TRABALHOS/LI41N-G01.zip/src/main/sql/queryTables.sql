USE LS2;

/**
	1)Alterar propriedades dum docente

	2)Alterar propriedades duma unidade curricular
	
	3)Remover docente

	4)Remover unidade curricular
	
	5)Associar uma unidade curricular existente a um curso. 
	
	6)Remover a associa��o entre uma unidade curricular e um curso. 
	
	7)Alterar a lista de docentes que leccionam uma unidade curricular, num semestre lectivo.
	
	8)Alterar o respons�vel duma unidade curricular, a partir do semestre indicado
	
	9)Criar um curso.
**/

DECLARE @anoLectFim VARCHAR(5)= '10/11', @semLectFim VARCHAR(3)='ver', @numDocente INT = 1017

SET XACT_ABORT ON
BEGIN TRANSACTION
	/*INSERT INTO SEMLECTIVO(anoLectivo,semLectivo,dataInicio,dataFim) VALUES('10/11','ver','01/02/2011','01/06/2011');*/
	UPDATE HIST_DOC_UC SET HIST_DOC_UC.anoLectFim=@anoLectFim, HIST_DOC_UC.semLectFim=@semLectFim
		WHERE HIST_DOC_UC.numDocente=@numDocente AND HIST_DOC_UC.anoLectFim IS NULL;
		
	UPDATE HIST_PROF_CURSO SET HIST_PROF_CURSO.anoLectFim=@anoLectFim, HIST_PROF_CURSO.semLectFim=@semLectFim
		WHERE HIST_PROF_CURSO.numDocente=@numDocente AND HIST_PROF_CURSO.anoLectFim IS NULL;
		
	UPDATE HIST_PROF_UC SET HIST_PROF_UC.anoLectFim=@anoLectFim, HIST_PROF_UC.semLectFim=@semLectFim
		WHERE HIST_PROF_UC.numDocente=@numDocente AND HIST_PROF_UC.anoLectFim IS NULL
COMMIT TRANSACTION

SELECT HIST_DOC_UC.numDocente, HIST_DOC_UC.anoLectIni, HIST_DOC_UC.anoLectFim, HIST_DOC_UC.acrUC
FROM HIST_DOC_UC
WHERE HIST_DOC_UC.numDocente=@numDocente;

SELECT HIST_PROF_UC.numDocente, HIST_PROF_UC.anoLectIni, HIST_PROF_UC.anoLectFim, HIST_PROF_UC.acrUC
FROM HIST_PROF_UC
WHERE HIST_PROF_UC.numDocente=@numDocente;

USE LS2
SELECT DOCENTE.numero, DOCENTE.nome, DOCENTE.email, DOCENTE.tipo
FROM DOCENTE WHERE DOCENTE.numero=100 ;