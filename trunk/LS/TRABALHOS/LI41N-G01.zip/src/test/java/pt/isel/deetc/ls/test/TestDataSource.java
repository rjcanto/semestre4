package pt.isel.deetc.ls.test;

import java.io.IOException;
import java.sql.*;

import org.junit.Test;

import pt.isel.deetc.ls.common.ApplicationDB;


public class TestDataSource {
	@Test
	public void TestConnectionSQLServer() throws IOException {
		try {
//			SQLServerDataSource dataSource = new SQLServerDataSource() ;  
//			dataSource.setDatabaseName("LS") ;
//			dataSource.setServerName("localhost") ;
//			dataSource.setPortNumber(1433) ;
//			dataSource.setUser("LS") ;
//			dataSource.setPassword("LS") ;
			ApplicationDB dts = new ApplicationDB();
			dts.getDataSource().getConnection();
		} catch (SQLException e) {
			e.printStackTrace() ;
		}
	}

}
