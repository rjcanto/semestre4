package pt.isel.deetc.ls.test;


import java.io.IOException;
import java.sql.SQLException;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pt.isel.deetc.ls.common.* ;

import pt.isel.deetc.ls.cmd.Command;
import pt.isel.deetc.ls.cmd.CommandLineEntryPoint;

import com.microsoft.sqlserver.jdbc.SQLServerException;

public class t1 {
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	

	@Test
	public void shouldConnectToDatabase() throws SQLServerException {
		ApplicationDB dts = new ApplicationDB();
		dts.getDataSource().getConnection();
	}
	
	@Test 
	public void CommandLineEntryPointMustFindCommands() throws  BadCommandException, SQLException, BadParameterException, IOException{
		final CommandLineEntryPoint cmd = new CommandLineEntryPoint();
		
		class cmd extends Command {
			String s;
			public cmd(String s){
				super(s);
				this.s=s;
			}
			@Override
			public String getDescription() {
				return s;
			}

			@Override
			public String getName() {
				return s;
			}

			@Override
			public void run() throws SQLException {
			}

			@Override
			public String usage() {
				return s;
			}
			@Override
			public void clear() {
			}

		}

		cmd.cmdAdd(new cmd("ABC"));
		cmd.cmdAdd(new cmd("DEF"));
		String t1 = "ABC";
		cmd.Execute(t1);
		String t2 = "-DEF";
		cmd.Execute(t2);
		String help = "-help";
		cmd.Execute(help);

	}
}
