package pt.isel.deetc.ls.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

/**
 * 
 * @author Canto
 * Criar um curso. 
 * Associar uma unidade curricular existente a um curso. 
 * Remover a associa��o entre uma unidade curricular e um curso. 
 * Alterar a lista de docentes que leccionam uma unidade curricular, num semestre lectivo. 
 * Alterar o respons�vel duma unidade curricular, a partir do semestre indicado
 * 
 */

public class TestDeleteTeacher {

	ApplicationDB dts ;
	SQLServerDataSource sqlserver ;
	Connection conn ;
	
	@Before
	public void setUp() throws SQLServerException {
		dts = new ApplicationDB() ;
		sqlserver = dts.getDataSource() ;
	}
	
	@Test
	public void testDeleteTeacher() throws SQLServerException,SQLException, BadParameterException, IOException {
		//insertCourse() ;
		CreateDB db = new CreateDB(sqlserver,true);
		db.run();
		Connection conn=sqlserver.getConnection();
		Teacher d = new Teacher(100, "Ricardo", "rjcanto@teste.pt", "Assistente") ;
		TeacherMapper tMapper = new TeacherMapper(conn) ;
		tMapper.insert(d) ;
		Semester s = new Semester("10/11","ver",Date.valueOf("2011-02-20"), Date.valueOf("2010-06-20"));
		SemesterMapper sMapper = new SemesterMapper(conn) ;
		sMapper.insert(s);
		tMapper.delete(d);
		conn.close() ;
	}
	
	@Test
	public void insertCourse() throws SQLServerException,SQLException {
		String defaultStmt ="insert into CURSO(acronimo,nome) values (?,?);";
		//Connection conn=null;
		try {
			conn = sqlserver.getConnection() ;
			PreparedStatement stmt=conn.prepareStatement(defaultStmt);
			stmt.setString(1, "MERCM");
			stmt.setString(2, "Mestrado em Engenharia de Redes de Comunica��o e Multim�dia");
			conn.setAutoCommit(false) ;
			stmt.executeUpdate();
			conn.commit() ;	
		}finally {
			 if(!conn.isClosed())
				conn.close();
		}
	}
	
	public void updateTeacher() throws SQLServerException,SQLException {
		String defaultStmt = "UPDATE DOCENTE SET DOCENTE.tipo=? WHERE DOCENTE.numero=?";
		//Connection conn=null;
		try {
			conn = sqlserver.getConnection() ;
			PreparedStatement stmt=conn.prepareStatement(defaultStmt);
			stmt.setString(1, "professor");
			stmt.setInt(2, 100);
			conn.setAutoCommit(false) ;
			stmt.executeUpdate();
			conn.commit() ;	
		}
		 finally {
			 if(!conn.isClosed())
				conn.close();
		 }
	}
	
	public void deleteTeacher(Teacher t, Semester s) throws SQLServerException,SQLException {
		String updateHistDocUC = "UPDATE HIST_DOC_UC SET HIST_DOC_UC.anoLectFim=?, HIST_DOC_UC.semLectFim=?" +
			" WHERE HIST_DOC_UC.numDocente=? AND HIST_DOC_UC.anoLectFim IS NULL";
		String updateHistProfCurso = "UPDATE HIST_PROF_CURSO SET "+
			"HIST_PROF_CURSO.anoLectFim=?, HIST_PROF_CURSO.semLectFim=?" +
			"WHERE HIST_PROF_CURSO.numDocente=? AND HIST_PROF_CURSO.anoLectFim IS NULL;" ;
		String updateHistProfUC = "UPDATE HIST_PROF_UC SET "+
			"HIST_PROF_UC.anoLectFim=?, HIST_PROF_UC.semLectFim=? " +
			"WHERE HIST_PROF_UC.numDocente=? AND HIST_PROF_UC.anoLectFim IS NULL;" ;		
		//Connection conn=null;
		try {
			conn = sqlserver.getConnection() ;
			conn.setAutoCommit(false) ;
			
			PreparedStatement stmtHistDocUC=conn.prepareStatement(updateHistDocUC);
			stmtHistDocUC.setString(1, s.getYear());
			stmtHistDocUC.setString(2, s.getSeason());
			stmtHistDocUC.setInt(3, t.getNBRMEC()) ;
			stmtHistDocUC.executeUpdate();
			
			PreparedStatement stmtHistProfCurso=conn.prepareStatement(updateHistProfCurso);
			stmtHistProfCurso.setString(1, s.getYear());
			stmtHistProfCurso.setString(2, s.getSeason());
			stmtHistProfCurso.setInt(3, t.getNBRMEC()) ;
			stmtHistProfCurso.executeUpdate();
			
			PreparedStatement stmtHistProfUC=conn.prepareStatement(updateHistProfUC);
			stmtHistProfUC.setString(1, s.getYear());
			stmtHistProfUC.setString(2, s.getSeason());
			stmtHistProfUC.setInt(3, t.getNBRMEC()) ;
			stmtHistProfUC.executeUpdate();
			
			conn.commit() ;	
		}
		 finally {
			 if(!conn.isClosed())
				conn.close();
		 }
	}
	
}
