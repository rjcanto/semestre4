package pt.isel.deetc.ls.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

import static org.junit.Assert.* ;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.cmd.etapa2.AddTeacherToUC;
import pt.isel.deetc.ls.cmd.etapa2.RemoveTeacherFromUC;
import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

public class TestChangeTeacherInUC {
	ApplicationDB _dts ;
	SQLServerDataSource _sqlserver ;
	Connection _conn ;
	
	@Before
	public void setUp() throws SQLServerException {
		_dts = new ApplicationDB() ;
		_sqlserver = _dts.getDataSource() ;
		_conn = _sqlserver.getConnection() ;
	}
	
	@Test
	public void testChangeTeacherInUC() throws SQLServerException,SQLException, BadParameterException, IOException {
		//** Mappers **//
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_sqlserver.getConnection()) ;
		SemesterMapper sMapper = new SemesterMapper(_sqlserver.getConnection()) ;
		TeacherMapper tMapper = new TeacherMapper(_sqlserver.getConnection()) ;
		
		//** Elements **//
		CurricularUnit uc = new CurricularUnit("PDI", "Processos Digitais Interm�dios", 6) ;
		Teacher t = new Teacher(115, "Ricardo", "rjcanto2@teste.pt", "professor") ;
		Semester s = new Semester("98/99","inv",Date.valueOf("1998-09-22"), Date.valueOf("1999-01-30")) ;
		
		// Clean up Database
		CreateDB db = new CreateDB(_sqlserver, true) ;
		db.run() ;
		
		// Validate entries in DB
		if(!tMapper.find(t)) tMapper.insert(t) ;
		assertTrue(tMapper.find(t)) ;
		assertTrue(tMapper.selectNumber(t.getNBRMEC()).equals(t)) ;
		if(!sMapper.find(s)) sMapper.insert(s) ;
		assertTrue(sMapper.find(s)) ;
		if(!ucMapper.find(uc)) ucMapper.insert(uc) ;
		assertTrue(ucMapper.find(uc)) ;
	
		// Add teacher to UC from year 98/99 to the future...
		AddTeacherToUC addTeacherToUCCMD = new AddTeacherToUC(_sqlserver) ;
		addTeacherToUCCMD.setUC(uc.getAcronym()) ;
		addTeacherToUCCMD.setTeacher(Integer.toString(t.getNBRMEC())) ;
		addTeacherToUCCMD.setYear(s.getYear()) ;
		addTeacherToUCCMD.setSeason(s.getSeason()) ;
		addTeacherToUCCMD.run() ;
		assertTrue(ucMapper.findTeacherUCinSemester(uc, t, s)) ;
		
		//Remove teacher from UC starting last year winter semester (08/09 inv)
		Semester sLast = new Semester("08/09","inv",Date.valueOf("2008-09-22"), Date.valueOf("2009-01-30")) ;
		sMapper.insert(sLast) ;
		RemoveTeacherFromUC rmvTeacherFromUCCMD = new RemoveTeacherFromUC(_sqlserver) ;
		rmvTeacherFromUCCMD.setUC(uc.getAcronym()) ;
		rmvTeacherFromUCCMD.setTeacher(Integer.toString(t.getNBRMEC())) ;
		rmvTeacherFromUCCMD.setYear(sLast.getYear()) ;
		rmvTeacherFromUCCMD.setSeason(sLast.getSeason()) ;
		rmvTeacherFromUCCMD.run() ;
		
		//So is he teaching in this semester (09/10 ver)?
		Semester sActual = new Semester("09/10","ver",Date.valueOf("2009-02-16"), Date.valueOf("2010-07-30")) ;
		assertFalse(ucMapper.findTeacherUCinSemester(uc, t, sActual)) ;
		
		Semester sPassado = new Semester("07/08","ver",Date.valueOf("2007-02-16"), Date.valueOf("2008-07-30")) ;
		assertTrue(ucMapper.findTeacherUCinSemester(uc, t, sPassado)) ;
	}
		
}
