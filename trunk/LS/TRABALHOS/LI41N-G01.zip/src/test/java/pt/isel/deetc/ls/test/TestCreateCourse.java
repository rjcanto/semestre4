package pt.isel.deetc.ls.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import static org.junit.Assert.* ;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.cmd.etapa2.CreateCourse;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.model.Course;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public class TestCreateCourse {
	
	ApplicationDB _db ;
	SQLServerDataSource _dts ;
	Connection _conn ;
	
	@Before
	public void SetUp() throws SQLServerException {
		_db = new ApplicationDB() ;
		_dts = _db.getDataSource() ;
		_conn = _dts.getConnection() ;
	}
	
	@Test 
	public void CreateCourse() throws SQLException, IOException {
		CreateDB db = new CreateDB(_dts, true) ;
		db.run() ;
		CreateCourse cCommand = new CreateCourse(_dts) ;
		cCommand.setAcronym("LAB") ;
		cCommand.setName("Licenciatura AB") ;
		cCommand.run() ;
		
		CourseMapper cMapper = new CourseMapper(_conn) ;
		assertTrue(cMapper.find(new Course("LAB","Licenciatura AB"))) ;	
	}
}
