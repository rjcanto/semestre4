package pt.isel.deetc.ls.test;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;


import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.cmd.etapa2.ChangeUCReponsible;
import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;


public class TestTeacher {

	ApplicationDB _dts ;
	SQLServerDataSource _sqlserver ;
	Connection _conn ;
	
	@Before
	public void setUp() throws SQLServerException {
		_dts = new ApplicationDB() ;
		_sqlserver = _dts.getDataSource() ;
	}
	
	@Test
	public void testTeacher() throws SQLServerException,SQLException, BadParameterException, IOException {
		
		//Entities
		Teacher d = new Teacher(101, "Ricardo", "rjcanto1@teste.pt", "Assistente") ;
		CurricularUnit uc = new CurricularUnit("PDI", "Processos Digitais Interm�dios", 6) ;
		Semester s = new Semester("10/11","ver",Date.valueOf("2011-02-20"), Date.valueOf("2011-06-20"));
		
		//Data Mappers
		TeacherMapper tMapper = new TeacherMapper(_sqlserver.getConnection()) ;
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_sqlserver.getConnection()) ;
		SemesterMapper sMapper = new SemesterMapper(_sqlserver.getConnection()) ;
		
		CreateDB db = new CreateDB(_sqlserver, true) ;
		db.run() ;
		
		if (!tMapper.find(d))
			tMapper.insert(d) ;
		assertTrue(tMapper.find(d)) ;
		
		if (!ucMapper.find(uc))
			ucMapper.insert(uc) ;
		assertTrue(ucMapper.find(uc)) ;
		
		if (!sMapper.find(s))
			sMapper.insert(s) ;
		assertTrue(sMapper.find(s)) ;
		
		ChangeUCReponsible changeUCReponsibleCMD = new ChangeUCReponsible(_sqlserver) ;
		changeUCReponsibleCMD.setTeacher(Integer.toString(d.getNBRMEC()));
		changeUCReponsibleCMD.setUC(uc.getAcronym()) ;
		changeUCReponsibleCMD.setYear(s.getYear()) ;
		changeUCReponsibleCMD.setSeason(s.getSeason()) ;
		changeUCReponsibleCMD.run() ;
		assertTrue(ucMapper.selectCurrentOwnerFromUC(uc).equals(d)) ;
		
		
	}
}
