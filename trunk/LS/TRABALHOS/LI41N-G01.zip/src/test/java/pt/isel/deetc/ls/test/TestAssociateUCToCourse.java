package pt.isel.deetc.ls.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.cmd.etapa2.AssociateUCCourse;
import pt.isel.deetc.ls.cmd.etapa2.CreateCourse;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class TestAssociateUCToCourse {

	ApplicationDB _db ;
	SQLServerDataSource _dts ;
	Connection _conn ;
	
	@Before
	public void setUp() throws Exception {
		_db = new ApplicationDB() ;
		_dts = _db.getDataSource() ;
		_conn = _dts.getConnection() ;
	}

	@Test 
	public void AssociateUCToCourse() throws SQLException, IOException, BadParameterException {
		CreateDB db = new CreateDB(_dts, true) ;
		db.run() ;
		
		Course c = new Course("LAB","Licenciatura AB") ;
		CreateCourse cCommand = new CreateCourse(_dts) ;
		cCommand.setAcronym(c.getAcr()) ;
		cCommand.setName(c.getNome()) ;
		cCommand.run() ;
		
		CourseMapper cMapper = new CourseMapper(_conn) ;
		assertTrue(cMapper.find(c)) ;	
		
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_conn) ;
		CurricularUnit uc = new CurricularUnit("LSA","Laborat�rio de Soft Avan�ado", 6) ;
		ucMapper.insert(uc) ;
		assertTrue(ucMapper.find(uc)) ;
		
		SemesterMapper sMapper = new SemesterMapper(_conn) ;
		Semester s = new Semester("10/11","ver",Date.valueOf("2011-02-20"), Date.valueOf("2010-06-20")) ;
		sMapper.insert(s) ;
		assertTrue(sMapper.find(s)) ;
		
		AssociateUCCourse uccCommand = new AssociateUCCourse(_dts) ;
		uccCommand.setCourse(c.getAcr()) ;
		uccCommand.setUC(uc.getAcronym()) ;
		uccCommand.setSemLect(s.getSeason()) ;
		uccCommand.setYearLect(s.getYear()) ;
		uccCommand.setSemCurr("2") ;
		uccCommand.setCaracter("obrigat�rio") ;
		uccCommand.run() ;
		assertTrue(cMapper.findActiveUCinCourse(c, uc)) ;
		
		/*Test CourseMapper method selectUCEndSemester */
		assertTrue(cMapper.selectUCEndSemester(c, uc)==null) ;
		
		Semester sEnd = new Semester("11/12","ver",Date.valueOf("2012-02-20"), Date.valueOf("2012-06-20")) ;
		sMapper.insert(sEnd) ;
		ucMapper.updateEndSemester(uc, c, sEnd) ;
		System.out.println(cMapper.selectUCEndSemester(c, uc).toString()) ;
		assertFalse(cMapper.selectUCEndSemester(c, uc)==null) ;
	}
}
