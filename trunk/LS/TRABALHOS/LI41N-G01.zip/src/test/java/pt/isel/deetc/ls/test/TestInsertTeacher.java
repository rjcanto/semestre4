package pt.isel.deetc.ls.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.cmd.etapa1.UpdateTeacher;
import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.mapper.TeacherMapper;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.model.Teacher;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

public class TestInsertTeacher {
	ApplicationDB _dts;
	SQLServerDataSource _sqlserver ;
	Connection _conn ;
	
	@Before
	public void setUp() throws SQLServerException {
		_dts = new ApplicationDB() ;
		_sqlserver = _dts.getDataSource() ;
		_conn = _sqlserver.getConnection() ;
	}
	
	@Test
	/**
	 * Test the UpdateOwner method in the Curricular Unit Mapper.
	 */
	public void testInsertTeacher() throws SQLServerException,SQLException, BadParameterException, IOException {
		
		CreateDB db = new CreateDB(_sqlserver,true);
		db.run();
		
		TeacherMapper tMapper = new TeacherMapper(_conn) ;
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_conn) ;
		SemesterMapper sMapper = new SemesterMapper(_conn) ;
		
		Semester s = new Semester("10/11","ver",Date.valueOf("2011-02-20"), Date.valueOf("2010-06-20")) ;
		Teacher d = new Teacher(115, "Ricardo", "rjcanto2@teste.pt", "Professor") ;
		CurricularUnit uc = new CurricularUnit("PDI","Processos Digitais Interm�dios", 6) ;
		if(!tMapper.find(d)) tMapper.insert(d) ;
		if(!sMapper.find(s)) sMapper.insert(s) ;
		if(!ucMapper.find(uc)) ucMapper.insert(uc) ;
		

		ucMapper.updateOwner(uc, d, s);
		
		Teacher dOwner = ucMapper.selectCurrentOwnerFromUC(uc) ;
		assertTrue(dOwner.equals(d)) ;
	}
	
	@Test
	/**
	 * Test the UpdateTeacher command.
	 */
	public void testUpdateTeacher() throws SQLException, IOException {
		CreateDB db = new CreateDB(_sqlserver,true);
		db.run();
		
		TeacherMapper tMapper = new TeacherMapper(_conn) ;
		Teacher d = new Teacher(115, "Ricardo", "rjcanto2@teste.pt", "Professor") ;
		if(!tMapper.find(d)) tMapper.insert(d) ;
		
		UpdateTeacher UpdateTeacherCMD = new UpdateTeacher(_sqlserver) ;
		UpdateTeacherCMD.setTeacher((new Integer(d.getNBRMEC())).toString()) ;
		UpdateTeacherCMD.setType("Assistente") ;
		UpdateTeacherCMD.run() ;
		Teacher dNew = new Teacher(115, "Ricardo", "rjcanto2@teste.pt", "assistente") ;
		assertEquals(dNew,tMapper.selectNumber(115));
	}
}
