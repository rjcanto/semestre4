package pt.isel.deetc.ls.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.cmd.etapa2.CreateCourse;
import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.mapper.*;
import pt.isel.deetc.ls.model.*;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class TestUpdateUCCourse {
	ApplicationDB _db ;
	SQLServerDataSource _dts ;
	Connection _conn ;
	
	@Before
	public void setUp() throws Exception {
		_db = new ApplicationDB() ;
		_dts = _db.getDataSource() ;
		_conn = _dts.getConnection() ;
	}

	@Test 
	public void updateUCCourse() throws SQLException, IOException, BadParameterException {
		CreateDB db = new CreateDB(_dts, true) ;
		db.run() ;
		
		Course c = new Course("LAB","Licenciatura AB") ;
		CreateCourse cCommand = new CreateCourse(_dts) ;
		cCommand.setAcronym(c.getAcr()) ;
		cCommand.setName(c.getNome()) ;
		cCommand.run() ;
		
		CourseMapper cMapper = new CourseMapper(_conn) ;
		assertTrue(cMapper.find(c)) ;	
		
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_conn) ;
		CurricularUnit uc = new CurricularUnit("LSA","Laboratorio de Soft Avancado", 6) ;
		ucMapper.insert(uc) ;
		assertTrue(ucMapper.find(uc)) ;
		
		SemesterMapper sMapper = new SemesterMapper(_conn) ;
		Semester sBegin = new Semester("10/11","ver",Date.valueOf("2011-02-20"), Date.valueOf("2011-06-20")) ;
		sMapper.insert(sBegin) ;
		assertTrue(sMapper.find(sBegin)) ;
		
		int semCurricular = 1;
		String type = "opcional" ;
		assertTrue(uc.validateType(type)) ;
		
		ucMapper.insert(uc, c, sBegin, semCurricular, type) ;
		assertTrue(cMapper.findActiveUCinCourse(c,uc)) ;
		
		semCurricular = 2;
		Semester sNewBegin = new Semester("11/12","ver",Date.valueOf("2012-02-20"), Date.valueOf("2012-06-20")) ;
		sMapper.insert(sNewBegin) ;
		assertTrue(sMapper.find(sNewBegin)) ;
		ucMapper.updateUCCourse(c, uc, sNewBegin, semCurricular, type) ;
	}
}
