package pt.isel.deetc.ls.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;

import static org.junit.Assert.* ;

import org.junit.Before;
import org.junit.Test;

import pt.isel.deetc.ls.common.ApplicationDB;
import pt.isel.deetc.ls.common.BadParameterException;
import pt.isel.deetc.ls.mapper.CourseMapper;
import pt.isel.deetc.ls.mapper.CurricularUnitMapper;
import pt.isel.deetc.ls.mapper.SemesterMapper;
import pt.isel.deetc.ls.model.Course;
import pt.isel.deetc.ls.model.CurricularUnit;
import pt.isel.deetc.ls.model.Semester;
import pt.isel.deetc.ls.cmd.CreateDB;
import pt.isel.deetc.ls.cmd.RemoveUC;
import pt.isel.deetc.ls.cmd.etapa1.UpdateUC;
import pt.isel.deetc.ls.cmd.etapa2.AssociateUCCourse;
import pt.isel.deetc.ls.cmd.etapa2.CreateCourse;

public class TestUC {
		
	ApplicationDB _dts ;
	SQLServerDataSource _sqlserver ;
	Connection _conn ;
	
	@Before
	public void setUp() throws SQLServerException {
		_dts = new ApplicationDB() ;
		_sqlserver = _dts.getDataSource() ;
		_conn = _sqlserver.getConnection() ;
	}
	
	@Test
	public void testUCCourse() throws SQLServerException,SQLException, BadParameterException, IOException {
		
		//** Mappers **//
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_sqlserver.getConnection()) ;
		SemesterMapper sMapper = new SemesterMapper(_sqlserver.getConnection()) ;
		
		//** Elements **//
		CurricularUnit uc = new CurricularUnit("PDI", "Processos Digitais Interm�dios", 6) ;
		Course c = new Course("LAB","Licenciatura AB") ;
		
		//** Cleaning Database **//
		CreateDB db = new CreateDB(_sqlserver, true) ;
		db.run() ;
		
		Semester s = new Semester("10/11","ver",Date.valueOf("2011-02-20"), Date.valueOf("2010-06-20"));
		sMapper.insert(s) ;
		assertTrue(sMapper.find(s)) ;

		// Creating the course through the command CreateCourse			
		CreateCourse cCommand = new CreateCourse(_sqlserver) ;
		cCommand.setAcronym(c.getAcr()) ;
		cCommand.setName(c.getNome()) ;
		cCommand.run() ;
		
		//Checking if the course was correctly created
		CourseMapper cMapper = new CourseMapper(_conn) ;
		assertTrue(cMapper.find(c)) ;	
		
		if (!ucMapper.find(uc))
			ucMapper.insert(uc) ;
		assertTrue(ucMapper.find(uc)) ;
		
		//Let's associate the Curricular Unit and the Course
		AssociateUCCourse associateUCCourseCMD  = new AssociateUCCourse(_sqlserver) ;
		associateUCCourseCMD.setUC(uc.getAcronym()) ;
		associateUCCourseCMD.setCourse(c.getAcr()) ;
		associateUCCourseCMD.setYearLect(s.getYear()) ;
		associateUCCourseCMD.setSemLect(s.getSeason()) ;
		associateUCCourseCMD.setSemCurr("1") ;
		associateUCCourseCMD.setCaracter("opcional") ;
		associateUCCourseCMD.run() ;
		assertTrue(cMapper.findActiveUCinCourse(c,uc)) ;
		
		//Change Curricular Unit type.
		Semester sChange = new Semester("11/12","inv",Date.valueOf("2011-09-20"), Date.valueOf("2012-01-20"));
		sMapper.insert(sChange) ;
		UpdateUC updateUCCMD = new UpdateUC(_sqlserver) ;
		updateUCCMD.clear() ;
		updateUCCMD.setUC(uc.getAcronym()) ;
		updateUCCMD.setCourse(c.getAcr()) ;
		updateUCCMD.setSemYear(sChange.getYear()) ;
		updateUCCMD.setSemSeason(sChange.getSeason()) ;
		updateUCCMD.setReq("obrigat�rio") ;
		updateUCCMD.run() ;
		String s1=cMapper.selectType(c, uc);
		assertEquals("obrigat�rio",s1);
		
	
		//Remove association with course starting from semester sEnd ;
		Semester sEnd = new Semester("11/12","ver",Date.valueOf("2012-02-20"), Date.valueOf("2012-06-20"));
		sMapper.insert(sEnd) ;
				
		RemoveUC unlinkUCCourseCMD = new RemoveUC(_sqlserver) ;
		unlinkUCCourseCMD.setCourse(c.getAcr()) ;
		unlinkUCCourseCMD.setUC(uc.getAcronym()) ;
		unlinkUCCourseCMD.setYearLect(sEnd.getYear()) ;
		unlinkUCCourseCMD.setSemLect(sEnd.getSeason()) ;
		unlinkUCCourseCMD.run() ;
		assertFalse(cMapper.findActiveUCinCourse(c,uc)) ;
	}
	
	@Test
	public void testUpdateUC() throws SQLServerException,SQLException, BadParameterException, IOException {
		
		//** Mappers **//
		CurricularUnitMapper ucMapper = new CurricularUnitMapper(_sqlserver.getConnection()) ;
		
		//** Elements **//
		CurricularUnit ucOriginal = new CurricularUnit("PDI", "Processos Digitais Interm�dios", 6) ;
		
		//** Cleaning Database **//
		CreateDB db = new CreateDB(_sqlserver, true) ;
		db.run() ;

		if (!ucMapper.find(ucOriginal))
			ucMapper.insert(ucOriginal) ;
		assertTrue(ucMapper.find(ucOriginal)) ;
		
		CurricularUnit ucEctsNameChanged = new CurricularUnit("PDI", "Processos Interm�dios",  9) ;
		UpdateUC updateUCCMD = new UpdateUC(_sqlserver) ;
		updateUCCMD.setUC(ucOriginal.getAcronym()) ;
		updateUCCMD.setEcts("9") ;
		updateUCCMD.setName("Processos Interm�dios") ;
		updateUCCMD.run() ;
		assertEquals(ucEctsNameChanged,ucMapper.selectAcronimo("PDI")) ;
	}
}
