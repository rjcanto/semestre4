/*
*	Laborat�rio de Software
*	2009/2010 Semestre Ver�o
*	Trabalho (Etapa 2)
*	
*	Elaborado por:
*	Grupo 1
*	10044 � Jos� Costa
*	30896 � Ricardo Canto
*	
*/
CREATE TABLE DOCENTE(
	numero int,
	nome varchar(100) not null,
	email varchar(100) not null,
	tipo varchar(10) not null, /*"Professor" ou "Assistente"*/
	CONSTRAINT pk_DOCENTE PRIMARY KEY ( numero ), 
	CONSTRAINT ak_DOCENTE UNIQUE (email),
	CONSTRAINT ck_DOCENTE_NUMERO CHECK ( numero > 0 )
);

CREATE TABLE UC(
	acronimo varchar(10),
	nome varchar(100) not null,
	creditos real not null,
	CONSTRAINT pk_UC PRIMARY KEY ( acronimo ),
	CONSTRAINT ck_UC_CREDITOS CHECK ( creditos > 0 ),
) ;

CREATE TABLE CONTACTO_UC(
	acrUC varchar(10) not null,
	tipo varchar(5) not null,
	horas real not null,
	CONSTRAINT pk_CONTACTO_UC PRIMARY KEY (acrUC, tipo),
	CONSTRAINT fk_CONTACTO_UC FOREIGN KEY ( acrUC )
		REFERENCES UC ( acronimo ) ON UPDATE CASCADE
) ;

CREATE TABLE SEMLECTIVO(
	anoLectivo varchar(5), /*'??/??'*/
	semLectivo varchar(3), /* 'inv' ou 'ver' */
	dataInicio date not null,
	dataFim date,
	CONSTRAINT pk_SEMLECTIVO PRIMARY KEY ( anoLectivo, semLectivo ),
	CONSTRAINT ak1_SEMLECTIVO UNIQUE ( dataInicio ),
	CONSTRAINT ak2_SEMLECTIVO UNIQUE ( dataFim )
);

CREATE TABLE CURSO(
	acronimo varchar(5),
	nome varchar(100),
	CONSTRAINT pk_CURSO PRIMARY KEY ( acronimo ),
	CONSTRAINT ak_CURSO UNIQUE ( nome ),
);

CREATE TABLE HIST_PROF_CURSO(
	anoLectIni varchar(5), /*'??/??'*/
	semLectIni varchar(3), /* 'inv' ou 'ver' */
	anoLectFim varchar(5), /*'??/??'*/
	semLectFim varchar(3), /* 'inv' ou 'ver' */
	acrCurso varchar(5),
	numDocente int, /* Retirou-se not null pois pode acontecer o curso n�o ter um respons�vel, 
					por exemplo quando o curso deixar de ser leccionado */
	CONSTRAINT pk_HIST_PROF_CURSO PRIMARY KEY ( anoLectIni, semLectIni, acrCurso ),
	CONSTRAINT fk1_HIST_PROF_CURSO FOREIGN KEY ( anoLectIni, semLectIni )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk2_HIST_PROF_CURSO FOREIGN KEY ( anoLectFim, semLectFim )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk3_HIST_PROF_CURSO FOREIGN KEY ( acrCurso )
		REFERENCES CURSO ( acronimo )
);

CREATE TABLE HIST_DOC_UC(
	numDocente int,
	anoLectIni varchar(5), /*'??/??'*/
	semLectIni varchar(3), /* 'inv' ou 'ver' */
	anoLectFim varchar(5), /*'??/??'*/
	semLectFim varchar(3), /* 'inv' ou 'ver' */
	acrUC varchar(10), 
	CONSTRAINT pk_HIST_DOC_UC PRIMARY KEY ( numDocente, anoLectIni, semLectIni, acrUC ),
	CONSTRAINT fk1_HIST_DOC_UC FOREIGN KEY ( numDocente )
		REFERENCES DOCENTE ( numero ),
	CONSTRAINT fk2_HIST_DOC_UC FOREIGN KEY ( anoLectIni, semLectIni )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk3_HIST_DOC_UC FOREIGN KEY ( anoLectFim, semLectFim )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk4_HIST_DOC_UC FOREIGN KEY ( acrUC )
		REFERENCES UC ( acronimo )
);

CREATE TABLE HIST_PROF_UC(
	anoLectIni varchar(5), /*'??/??'*/
	semLectIni varchar(3), /* 'inv' ou 'ver' */
	anoLectFim varchar(5), /*'??/??'*/
	semLectFim varchar(3), /* 'inv' ou 'ver' */
	acrUC varchar(10),
	numDocente int, /* Retirou-se not null pois pode acontecer a cadeira n�o ter um respons�vel */
	CONSTRAINT pk_HIST_PROF_UC PRIMARY KEY ( anoLectIni, semLectIni, acrUC ),
	CONSTRAINT fk1_HIST_PROF_UC FOREIGN KEY ( anoLectIni, semLectIni )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk2_HIST_PROF_UC FOREIGN KEY ( anoLectFim, semLectFim )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk3_HIST_PROF_UC FOREIGN KEY ( acrUC )
		REFERENCES UC ( acronimo )
);

CREATE TABLE HIST_CURSO_UC(
	acrCurso varchar(5),
	acrUC varchar(10),
	anoLectIni varchar(5), /*'??/??'*/
	semLectIni varchar(3), /* 'inv' ou 'ver' */
	anoLectFim varchar(5), /*'??/??'*/
	semLectFim varchar(3), /* 'inv' ou 'ver' */
	semCurricular int not null,
	caracter varchar(11) not null, /* "obrigat�rio" ou "opcional" */
	CONSTRAINT pk_HIST_CURSO_UC PRIMARY KEY ( acrCurso, acrUC, anoLectIni, semLectIni ),
	CONSTRAINT fk1_HIST_CURSO_UC FOREIGN KEY ( acrCurso )
		REFERENCES CURSO ( acronimo ),
	CONSTRAINT fk2_HIST_CURSO_UC FOREIGN KEY ( anoLectIni, semLectIni )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk3_HIST_CURSO_UC FOREIGN KEY ( anoLectFim, semLectFim )
		REFERENCES SEMLECTIVO ( anoLectivo, semLectivo ),
	CONSTRAINT fk4_HIST_CURSO_UC FOREIGN KEY ( acrUC )
		REFERENCES UC ( acronimo )
);
