#ifndef BOARDINTERFACE_H
#define BOARDINTERFACE_H
#include "newtypes.h"

struct board_t;
typedef struct board_t Board;


#endif
