#ifndef NEWTYPES_H
#define NEWTYPES_H

enum bool {false,true};
typedef enum bool boolean;
typedef char byte;

#endif
