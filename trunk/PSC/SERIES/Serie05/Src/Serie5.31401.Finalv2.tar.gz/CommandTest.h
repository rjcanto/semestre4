#ifndef COMMANDTEST_H
#define COMMANDTEST_H
#include "newtypes.h"
#include "Command.h"
#include "GameInterface.h"
#include <stdio.h>
#include <stdlib.h>

 
typedef struct miner{
	Game_Methods* gvptr;
	boolean exit;	
}Miner;


#endif
