/*
Turma: 	LI31N
Nome: 	Nuno Cancelo
Numero: 31401
*/
#ifndef _SERIE02_EX01
#define _SERIE02_EX01

#include "serie01.h"
#define STR_MAX_SIZE 255
#define MAX_SIZE 510

char * xstrcat(char * str1, const char * str2);
char * astrcat(char * str1, const char * str2);
#endif
