/*
Turma: 	LI31N
Nome: 	Nuno Cancelo
Numero: 31401
*/
#ifndef _SERIE01
#define _SERIE01
/*
 * Constantes definidas
 * */
#define SUCCESS 0
#define UNSUCCESS 1
#define TRUE 1
#define FALSE 0

#endif
